<?php
/**
 * MySQL database configuration.
 * Update these values to match your WAMP MySQL setup.
 */
return [
    'host'     => '127.0.0.1',
    'port'     => 3306,
    'dbname'   => 'expense_ledger',
    'username' => 'root',
    'password' => '',          // WAMP default root has no password
    'charset'  => 'utf8mb4',
];
