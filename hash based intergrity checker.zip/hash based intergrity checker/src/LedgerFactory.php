<?php

declare(strict_types=1);

namespace ExpenseLedger;

/**
 * Convenience factory that wires components into ready-to-use instances.
 *
 * When an HMAC key is provided, HmacHasher is used instead of plain SHA-256 Hasher,
 * preventing attackers from recomputing valid hashes after tampering.
 */
final class LedgerFactory
{
    public static function create(?string $hmacKey = null): Ledger
    {
        $serializer = new Serializer();
        $hasher     = $hmacKey !== null
            ? new HmacHasher($serializer, $hmacKey)
            : new Hasher($serializer);

        return new Ledger($hasher);
    }

    public static function createVerifier(?string $hmacKey = null): Verifier
    {
        $serializer = new Serializer();
        $hasher     = $hmacKey !== null
            ? new HmacHasher($serializer, $hmacKey)
            : new Hasher($serializer);

        return new Verifier($hasher);
    }

    public static function createSerializer(): Serializer
    {
        return new Serializer();
    }
}
