<?php

declare(strict_types=1);

namespace ExpenseLedger;

/**
 * Value object describing a single tampered entry detected during verification.
 */
final class TamperedEntryInfo
{
    public function __construct(
        public readonly string $id,
        public readonly int $position,
        public readonly string $expected_hash,
        public readonly string $actual_hash,
    ) {}
}
