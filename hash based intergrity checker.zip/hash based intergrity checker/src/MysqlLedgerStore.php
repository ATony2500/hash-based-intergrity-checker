<?php
declare(strict_types=1);
namespace ExpenseLedger;

/**
 * MySQL-backed store for the ledger chain.
 *
 * Drop-in replacement for SqliteLedgerStore.
 * Regular users see only their own entries; admins see all.
 */
final class MysqlLedgerStore
{
    private \PDO $pdo;

    public function __construct(
        private int  $userId  = 0,
        private bool $isAdmin = false,
    ) {
        $this->pdo = Database::connect();
    }

    /** Append a HashedEntry for the current user. */
    public function append(HashedEntry $he): void
    {
        try {
            $stmt = $this->pdo->prepare(
                "INSERT INTO ledger_entries
                    (entry_id, amount, description, date, category, entry_hash, prev_hash, user_id)
                 VALUES
                    (:entry_id, :amount, :description, :date, :category, :entry_hash, :prev_hash, :user_id)"
            );
            $stmt->execute([
                ':entry_id'    => $he->entry->id,
                ':amount'      => $he->entry->amount,
                ':description' => $he->entry->description,
                ':date'        => $he->entry->date,
                ':category'    => $he->entry->category,
                ':entry_hash'  => $he->entry_hash,
                ':prev_hash'   => $he->prev_hash,
                ':user_id'     => $this->userId,
            ]);
        } catch (\PDOException $e) {
            if ($e->getCode() === '23000') {
                throw new \RuntimeException(
                    "An entry with ID '{$he->entry->id}' already exists. Please use a unique ID."
                );
            }
            throw $e;
        }
    }

    /** Load entries in chain order. Admins see all; users see their own. */
    public function loadAll(): array
    {
        if ($this->isAdmin) {
            $stmt = $this->pdo->query(
                'SELECT * FROM ledger_entries ORDER BY position ASC'
            );
        } else {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM ledger_entries WHERE user_id = :uid ORDER BY position ASC'
            );
            $stmt->execute([':uid' => $this->userId]);
        }

        $entries = [];
        foreach ($stmt->fetchAll() as $row) {
            $entries[] = new HashedEntry(
                new ExpenseEntry(
                    $row['entry_id'],
                    $row['amount'],
                    $row['description'],
                    $row['date'],
                    $row['category'],
                ),
                $row['entry_hash'],
                $row['prev_hash'],
            );
        }
        return $entries;
    }

    /** Mutate an entry's amount without recomputing the hash (demo tamper). */
    public function tamperAmount(string $entryId, string $newAmount): bool
    {
        if ($this->isAdmin) {
            $stmt = $this->pdo->prepare(
                'UPDATE ledger_entries SET amount = :amount WHERE entry_id = :id'
            );
            $stmt->execute([':amount' => $newAmount, ':id' => $entryId]);
        } else {
            $stmt = $this->pdo->prepare(
                'UPDATE ledger_entries SET amount = :amount WHERE entry_id = :id AND user_id = :uid'
            );
            $stmt->execute([':amount' => $newAmount, ':id' => $entryId, ':uid' => $this->userId]);
        }
        return $stmt->rowCount() > 0;
    }

    /** Record a verification run in the audit log. */
    public function logVerification(IntegrityReport $report): void
    {
        $tamperedIds = implode(',', array_map(
            fn(TamperedEntryInfo $t) => $t->id,
            $report->tampered_entries
        ));
        $stmt = $this->pdo->prepare(
            "INSERT INTO audit_log (status, entry_count, tampered_ids, user_id)
             VALUES (:status, :count, :ids, :uid)"
        );
        $stmt->execute([
            ':status' => $report->status,
            ':count'  => $report->verified_count,
            ':ids'    => $tamperedIds,
            ':uid'    => $this->userId,
        ]);
    }

    /** Recent audit log rows for this user (or all if admin). */
    public function recentAuditLog(int $limit = 10): array
    {
        if ($this->isAdmin) {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM audit_log ORDER BY id DESC LIMIT :limit'
            );
        } else {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM audit_log WHERE user_id = :uid ORDER BY id DESC LIMIT :limit'
            );
            $stmt->bindValue(':uid', $this->userId, \PDO::PARAM_INT);
        }
        $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /** Delete this user's entries and audit log (admin clears everything). */
    public function clear(): void
    {
        if ($this->isAdmin) {
            $this->pdo->exec('DELETE FROM ledger_entries');
            $this->pdo->exec('DELETE FROM audit_log');
        } else {
            $stmt = $this->pdo->prepare('DELETE FROM ledger_entries WHERE user_id = :uid');
            $stmt->execute([':uid' => $this->userId]);
            $stmt = $this->pdo->prepare('DELETE FROM audit_log WHERE user_id = :uid');
            $stmt->execute([':uid' => $this->userId]);
        }
    }
}
