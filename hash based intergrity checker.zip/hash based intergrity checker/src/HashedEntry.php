<?php

declare(strict_types=1);

namespace ExpenseLedger;

use ExpenseLedger\Exception\ValidationException;

/**
 * Immutable value object pairing an ExpenseEntry with its computed SHA-256
 * entry hash and the preceding entry's hash (prev_hash).
 *
 * Both hash fields must be 64-character lowercase hex strings.
 * For the genesis entry, prev_hash is the 64-character zero string.
 */
final class HashedEntry
{
    /** The 64-character zero hex string used as prev_hash for the genesis entry. */
    public const ZERO_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

    public readonly ExpenseEntry $entry;

    /** SHA-256 of canonical(entry) || prev_hash_bytes — 64 lowercase hex chars. */
    public readonly string $entry_hash;

    /** The preceding entry's entry_hash, or ZERO_HASH for the genesis entry. */
    public readonly string $prev_hash;

    public function __construct(
        ExpenseEntry $entry,
        string $entry_hash,
        string $prev_hash,
    ) {
        self::assertHex64('entry_hash', $entry_hash);
        self::assertHex64('prev_hash', $prev_hash);

        $this->entry      = $entry;
        $this->entry_hash = $entry_hash;
        $this->prev_hash  = $prev_hash;
    }

    // -------------------------------------------------------------------------
    // Validation helpers
    // -------------------------------------------------------------------------

    private static function assertHex64(string $field, string $value): void
    {
        if (!preg_match('/^[0-9a-f]{64}$/', $value)) {
            throw new ValidationException(
                "Field '{$field}' must be a 64-character lowercase hex string; got \"{$value}\"."
            );
        }
    }
}
