<?php

declare(strict_types=1);

namespace ExpenseLedger;

use ExpenseLedger\HasherInterface;
use ExpenseLedger\Exception\NotFoundException;

/**
 * Stateless component that verifies the integrity of a Ledger or individual entries
 * by recomputing SHA-256 hashes and comparing them against stored values.
 */
final class Verifier
{
    public function __construct(private readonly HasherInterface $hasher) {}

    /**
     * Verify the integrity of the entire ledger in chain order.
     *
     * @param object $ledger Any object with an `entries(): HashedEntry[]` method.
     * @return IntegrityReport
     */
    public function verifyLedger(object $ledger): IntegrityReport
    {
        $entries = $ledger->entries();

        if (empty($entries)) {
            return new IntegrityReport('intact', 0, []);
        }

        $tampered = [];

        foreach ($entries as $i => $hashedEntry) {
            $prevHash = ($i === 0)
                ? HasherInterface::ZERO_HASH
                : $entries[$i - 1]->entry_hash;

            $expectedHash = $this->hasher->hashEntry($hashedEntry->entry, $prevHash);

            if ($expectedHash !== $hashedEntry->entry_hash) {
                $tampered[] = new TamperedEntryInfo(
                    $hashedEntry->entry->id,
                    $i,
                    $expectedHash,
                    $hashedEntry->entry_hash,
                );
            }
        }

        $status = empty($tampered) ? 'intact' : 'tampered';

        return new IntegrityReport($status, count($entries), $tampered);
    }

    /**
     * Verify the integrity of a single entry identified by $id.
     *
     * @param object $ledger Any object with an `entries(): HashedEntry[]` method.
     * @param string $id     The entry identifier to verify.
     * @return IntegrityReport
     * @throws NotFoundException If no entry with the given id exists in the ledger.
     */
    public function verifyEntry(object $ledger, string $id): IntegrityReport
    {
        $entries  = $ledger->entries();
        $found    = null;
        $position = -1;

        foreach ($entries as $i => $hashedEntry) {
            if ($hashedEntry->entry->id === $id) {
                $found    = $hashedEntry;
                $position = $i;
                break;
            }
        }

        if ($found === null) {
            throw new NotFoundException("Entry with id '{$id}' not found in ledger.");
        }

        $expectedHash = $this->hasher->hashEntry($found->entry, $found->prev_hash);

        if ($expectedHash !== $found->entry_hash) {
            return new IntegrityReport('tampered', 1, [
                new TamperedEntryInfo($id, $position, $expectedHash, $found->entry_hash),
            ]);
        }

        return new IntegrityReport('intact', 1, []);
    }
}
