<?php

declare(strict_types=1);

namespace ExpenseLedger;

/**
 * Immutable deserialized ledger — a readonly wrapper around an ordered array
 * of HashedEntry values reconstructed from JSON.
 */
final class DecodedLedger
{
    /** @var HashedEntry[] */
    private array $hashedEntries;

    /** @param HashedEntry[] $entries */
    public function __construct(array $entries)
    {
        $this->hashedEntries = $entries;
    }

    /** @return HashedEntry[] */
    public function entries(): array
    {
        return $this->hashedEntries;
    }
}
