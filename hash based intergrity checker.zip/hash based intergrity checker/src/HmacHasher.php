<?php

declare(strict_types=1);

namespace ExpenseLedger;

/**
 * HMAC-SHA-256 hasher.
 *
 * Adds a secret key to the hash computation so an attacker who modifies
 * ledger data cannot simply recompute valid hashes — they would need the key.
 *
 * entry_hash = HMAC-SHA256( key, canonicalBytes(entry) . hex2bin(prevHash) )
 */
final class HmacHasher implements HasherInterface
{
    public const ZERO_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

    public function __construct(
        private readonly Serializer $serializer,
        private readonly string $secretKey,
    ) {
        if ($secretKey === '') {
            throw new \InvalidArgumentException('HMAC secret key must not be empty.');
        }
    }

    public function hashEntry(ExpenseEntry $entry, string $prevHash): string
    {
        $canonical = $this->serializer->canonicalBytes($entry);
        $prevBytes = hex2bin($prevHash);

        return hash_hmac('sha256', $canonical . $prevBytes, $this->secretKey, false);
    }
}
