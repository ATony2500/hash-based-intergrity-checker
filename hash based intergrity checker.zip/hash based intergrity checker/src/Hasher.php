<?php

declare(strict_types=1);

namespace ExpenseLedger;

/**
 * Stateless component responsible for computing SHA-256 entry hashes.
 *
 * Hash computation:
 *   entry_hash = SHA-256( canonicalBytes(entry) . hex2bin(prevHash) )
 *
 * The result is a 64-character lowercase hex string.
 * For the genesis entry, use ZERO_HASH as prevHash.
 */
final class Hasher implements HasherInterface
{
    /** The 64-character zero hex string used as prevHash for the genesis entry. */
    public const ZERO_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

    public function __construct(private readonly Serializer $serializer) {}

    /**
     * Compute the SHA-256 entry hash for the given entry chained against prevHash.
     *
     * @param ExpenseEntry $entry    The entry to hash.
     * @param string       $prevHash 64-character lowercase hex string of the preceding entry's hash,
     *                               or ZERO_HASH for the genesis entry.
     * @return string                64-character lowercase hex string.
     */
    public function hashEntry(ExpenseEntry $entry, string $prevHash): string
    {
        $canonical = $this->serializer->canonicalBytes($entry);
        $prevBytes = hex2bin($prevHash);

        return hash('sha256', $canonical . $prevBytes, false);
    }
}
