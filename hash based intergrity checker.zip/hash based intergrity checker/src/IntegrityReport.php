<?php

declare(strict_types=1);

namespace ExpenseLedger;

/**
 * Value object representing the result of a ledger or entry verification.
 *
 * @param string               $status           "intact" or "tampered"
 * @param int                  $verified_count   total entries verified
 * @param TamperedEntryInfo[]  $tampered_entries empty array when intact
 */
final class IntegrityReport
{
    /** @param TamperedEntryInfo[] $tampered_entries */
    public function __construct(
        public readonly string $status,
        public readonly int $verified_count,
        public readonly array $tampered_entries = [],
    ) {}
}
