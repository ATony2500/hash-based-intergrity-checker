<?php

declare(strict_types=1);

namespace ExpenseLedger;

interface HasherInterface
{
    public const ZERO_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

    public function hashEntry(ExpenseEntry $entry, string $prevHash): string;
}
