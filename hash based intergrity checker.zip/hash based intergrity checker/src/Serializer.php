<?php

declare(strict_types=1);

namespace ExpenseLedger;

use ExpenseLedger\Exception\ParseException;


/**
 * Stateless component responsible for canonical byte serialization of an
 * ExpenseEntry and JSON encoding/decoding of a Ledger.
 *
 * Canonical format (used for hashing):
 *   Each field is encoded as:  uint32_big_endian(strlen(field)) . field
 *   Fields are written in fixed order: id, amount, description, date, category
 *
 * This length-prefix scheme ensures the encoding is injective — no two distinct
 * entries can produce the same byte sequence.
 *
 * @phpstan-type LedgerLike object{entries(): HashedEntry[]}
 */
final class Serializer
{
    /**
     * Produce a deterministic, canonical byte string for the given entry.
     *
     * Each field is prefixed with its byte-length as a 4-byte big-endian uint32,
     * followed by the raw UTF-8 bytes of the field value.
     *
     * Field order: id, amount, description, date, category
     *
     * @param ExpenseEntry $entry The entry to serialize.
     * @return string             The raw binary canonical representation.
     */
    public function canonicalBytes(ExpenseEntry $entry): string
    {
        $fields = [
            $entry->id,
            $entry->amount,
            $entry->description,
            $entry->date,
            $entry->category,
        ];

        $result = '';
        foreach ($fields as $field) {
            // pack('N', n) produces a 4-byte big-endian unsigned 32-bit integer
            $result .= pack('N', strlen($field)) . $field;
        }

        return $result;
    }

    /**
     * Encode a Ledger to a JSON string.
     *
     * The output format is:
     * {
     *   "entries": [
     *     {
     *       "id": "...",
     *       "amount": "123.45",
     *       "description": "...",
     *       "date": "2024-01-15",
     *       "category": "...",
     *       "entry_hash": "abcd...ef",
     *       "prev_hash": "0000...00"
     *     }
     *   ]
     * }
     *
     * Amount is stored as a decimal string to avoid floating-point precision issues.
     *
     * @param object $ledger Any object with an `entries(): HashedEntry[]` method.
     * @return string        JSON-encoded ledger.
     */
    public function encodeLedger(object $ledger): string
    {
        $entries = [];
        foreach ($ledger->entries() as $hashedEntry) {
            $e = $hashedEntry->entry;
            $entries[] = [
                'id'          => $e->id,
                'amount'      => $e->amount,
                'description' => $e->description,
                'date'        => $e->date,
                'category'    => $e->category,
                'entry_hash'  => $hashedEntry->entry_hash,
                'prev_hash'   => $hashedEntry->prev_hash,
            ];
        }

        return json_encode(['entries' => $entries], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Decode a JSON string into a DecodedLedger.
     *
     * Throws ParseException if:
     *  - The JSON is malformed
     *  - The top-level "entries" key is missing or not an array
     *  - Any entry object is missing one of the 7 required fields:
     *    id, amount, description, date, category, entry_hash, prev_hash
     *
     * @param string $json JSON-encoded ledger produced by encodeLedger().
     * @return DecodedLedger Immutable wrapper around the reconstructed HashedEntry[].
     * @throws ParseException On any structural or field-level error.
     */
    public function decodeLedger(string $json): DecodedLedger
    {
        try {
            $data = json_decode($json, associative: true, flags: JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            throw new ParseException('Malformed JSON: ' . $e->getMessage(), 0, $e);
        }

        if (!is_array($data) || !array_key_exists('entries', $data)) {
            throw new ParseException("Missing required top-level key 'entries'.");
        }

        if (!is_array($data['entries'])) {
            throw new ParseException("Key 'entries' must be an array.");
        }

        $required = ['id', 'amount', 'description', 'date', 'category', 'entry_hash', 'prev_hash'];
        $hashedEntries = [];

        foreach ($data['entries'] as $index => $row) {
            if (!is_array($row)) {
                throw new ParseException("Entry at index {$index} must be an object.");
            }

            foreach ($required as $field) {
                if (!array_key_exists($field, $row)) {
                    throw new ParseException(
                        "Entry at index {$index} is missing required field '{$field}'."
                    );
                }
                if (!is_string($row[$field])) {
                    throw new ParseException(
                        "Entry at index {$index}: field '{$field}' must be a string."
                    );
                }
            }

            try {
                $expenseEntry = new ExpenseEntry(
                    $row['id'],
                    $row['amount'],
                    $row['description'],
                    $row['date'],
                    $row['category'],
                );
            } catch (\Exception $e) {
                throw new ParseException(
                    "Entry at index {$index} has invalid data: " . $e->getMessage(),
                    0,
                    $e,
                );
            }

            try {
                $hashedEntries[] = new HashedEntry(
                    $expenseEntry,
                    $row['entry_hash'],
                    $row['prev_hash'],
                );
            } catch (\Exception $e) {
                throw new ParseException(
                    "Entry at index {$index} has invalid hash data: " . $e->getMessage(),
                    0,
                    $e,
                );
            }
        }

        return new DecodedLedger($hashedEntries);
    }
}
