<?php
declare(strict_types=1);
namespace ExpenseLedger;

/**
 * Durable SQLite-backed store for the ledger chain.
 *
 * When userId > 0 and isAdmin = false, only that user's entries are visible.
 * When isAdmin = true, all entries from all users are loaded.
 */
final class SqliteLedgerStore
{
    private \PDO $pdo;

    public function __construct(
        string $dbPath,
        private int  $userId  = 0,
        private bool $isAdmin = false,
    ) {
        $this->pdo = new \PDO('sqlite:' . $dbPath);
        $this->pdo->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->pdo->exec('PRAGMA journal_mode=WAL');
        $this->createTables();
    }

    private function createTables(): void
    {
        $this->pdo->exec(
            "CREATE TABLE IF NOT EXISTS ledger_entries (
                position     INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_id     TEXT    NOT NULL UNIQUE,
                amount       TEXT    NOT NULL,
                description  TEXT    NOT NULL,
                date         TEXT    NOT NULL,
                category     TEXT    NOT NULL,
                entry_hash   TEXT    NOT NULL,
                prev_hash    TEXT    NOT NULL,
                created_at   TEXT    NOT NULL,
                user_id      INTEGER NOT NULL DEFAULT 0
            )"
        );

        $this->pdo->exec(
            "CREATE TABLE IF NOT EXISTS audit_log (
                id           INTEGER PRIMARY KEY AUTOINCREMENT,
                verified_at  TEXT    NOT NULL,
                status       TEXT    NOT NULL,
                entry_count  INTEGER NOT NULL,
                tampered_ids TEXT    NOT NULL,
                user_id      INTEGER NOT NULL DEFAULT 0
            )"
        );

        // Migrate existing DB: add user_id columns if they don't exist
        foreach (['ledger_entries', 'audit_log'] as $table) {
            try {
                $this->pdo->exec("ALTER TABLE {$table} ADD COLUMN user_id INTEGER NOT NULL DEFAULT 0");
            } catch (\PDOException) {
                // Already exists — ignore
            }
        }
    }

    /** Append a HashedEntry to the store for the current user. */
    public function append(HashedEntry $he): void
    {
        $stmt = $this->pdo->prepare(
            "INSERT INTO ledger_entries
                (entry_id, amount, description, date, category, entry_hash, prev_hash, created_at, user_id)
             VALUES
                (:entry_id, :amount, :description, :date, :category, :entry_hash, :prev_hash, :created_at, :user_id)"
        );
        $stmt->execute([
            ':entry_id'    => $he->entry->id,
            ':amount'      => $he->entry->amount,
            ':description' => $he->entry->description,
            ':date'        => $he->entry->date,
            ':category'    => $he->entry->category,
            ':entry_hash'  => $he->entry_hash,
            ':prev_hash'   => $he->prev_hash,
            ':created_at'  => gmdate('Y-m-d H:i:s'),
            ':user_id'     => $this->userId,
        ]);
    }

    /** Load entries in chain order. Admins see all; regular users see only their own. */
    public function loadAll(): array
    {
        if ($this->isAdmin) {
            $rows = $this->pdo
                ->query('SELECT * FROM ledger_entries ORDER BY position ASC')
                ->fetchAll(\PDO::FETCH_ASSOC);
        } else {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM ledger_entries WHERE user_id = :uid ORDER BY position ASC'
            );
            $stmt->execute([':uid' => $this->userId]);
            $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        }

        $entries = [];
        foreach ($rows as $row) {
            $entries[] = new HashedEntry(
                new ExpenseEntry(
                    $row['entry_id'],
                    $row['amount'],
                    $row['description'],
                    $row['date'],
                    $row['category'],
                ),
                $row['entry_hash'],
                $row['prev_hash'],
            );
        }
        return $entries;
    }

    /** Tamper with an entry's amount for demo purposes (does NOT recompute hash). */
    public function tamperAmount(string $entryId, string $newAmount): bool
    {
        if ($this->isAdmin) {
            $stmt = $this->pdo->prepare(
                'UPDATE ledger_entries SET amount = :amount WHERE entry_id = :id'
            );
            $stmt->execute([':amount' => $newAmount, ':id' => $entryId]);
        } else {
            $stmt = $this->pdo->prepare(
                'UPDATE ledger_entries SET amount = :amount WHERE entry_id = :id AND user_id = :uid'
            );
            $stmt->execute([':amount' => $newAmount, ':id' => $entryId, ':uid' => $this->userId]);
        }
        return $stmt->rowCount() > 0;
    }

    /** Write a verification result to the audit log. */
    public function logVerification(IntegrityReport $report): void
    {
        $tamperedIds = implode(',', array_map(
            fn(TamperedEntryInfo $t) => $t->id,
            $report->tampered_entries
        ));
        $stmt = $this->pdo->prepare(
            "INSERT INTO audit_log (verified_at, status, entry_count, tampered_ids, user_id)
             VALUES (:verified_at, :status, :count, :ids, :uid)"
        );
        $stmt->execute([
            ':verified_at' => gmdate('Y-m-d H:i:s'),
            ':status'      => $report->status,
            ':count'       => $report->verified_count,
            ':ids'         => $tamperedIds,
            ':uid'         => $this->userId,
        ]);
    }

    /** Return recent audit log entries for this user (or all if admin). */
    public function recentAuditLog(int $limit = 10): array
    {
        if ($this->isAdmin) {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM audit_log ORDER BY id DESC LIMIT :limit'
            );
            $stmt->bindValue(':limit', $limit, \PDO::PARAM_INT);
            $stmt->execute();
        } else {
            $stmt = $this->pdo->prepare(
                'SELECT * FROM audit_log WHERE user_id = :uid ORDER BY id DESC LIMIT :limit'
            );
            $stmt->bindValue(':uid',   $this->userId, \PDO::PARAM_INT);
            $stmt->bindValue(':limit', $limit,        \PDO::PARAM_INT);
            $stmt->execute();
        }
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /** Delete entries and audit log for the current user (or all if admin). */
    public function clear(): void
    {
        if ($this->isAdmin) {
            $this->pdo->exec('DELETE FROM ledger_entries');
            $this->pdo->exec('DELETE FROM audit_log');
        } else {
            $stmt = $this->pdo->prepare('DELETE FROM ledger_entries WHERE user_id = :uid');
            $stmt->execute([':uid' => $this->userId]);
            $stmt = $this->pdo->prepare('DELETE FROM audit_log WHERE user_id = :uid');
            $stmt->execute([':uid' => $this->userId]);
        }
    }
}
