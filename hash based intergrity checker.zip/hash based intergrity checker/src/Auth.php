<?php
declare(strict_types=1);
namespace ExpenseLedger;

/**
 * Session-based auth helper.
 * Call Auth::start() at the top of every page.
 * Call Auth::check() on protected pages.
 */
final class Auth
{
    public static function start(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            ini_set('session.cookie_httponly', '1');
            ini_set('session.use_strict_mode', '1');
            ini_set('session.cookie_samesite', 'Strict');
            session_name('LEDGER_SESS');
            session_start();
        }
    }

    /** Log a user in, regenerating the session ID to prevent fixation. */
    public static function login(array $user): void
    {
        session_regenerate_id(true);
        $_SESSION['user_id']   = (int) $user['id'];
        $_SESSION['username']  = $user['username'];
        $_SESSION['role']      = $user['role'];
        $_SESSION['logged_in'] = true;
    }

    /** Destroy session and expire the cookie. */
    public static function logout(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(
                session_name(), '', time() - 3600,
                $p['path'], $p['domain'], $p['secure'], $p['httponly']
            );
        }
        session_destroy();
    }

    /**
     * Require authentication. Redirects to login.php if not logged in.
     * Call at the top of every protected page after Auth::start().
     */
    public static function check(): void
    {
        self::start();
        if (empty($_SESSION['logged_in'])) {
            header('Location: login.php');
            exit;
        }
    }

    public static function isAdmin(): bool
    {
        return ($_SESSION['role'] ?? '') === 'admin';
    }

    public static function userId(): int
    {
        return (int) ($_SESSION['user_id'] ?? 0);
    }

    public static function username(): string
    {
        return (string) ($_SESSION['username'] ?? '');
    }

    /** Return (and create if needed) the CSRF token for the current session. */
    public static function csrf(): string
    {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }

    /**
     * Verify the CSRF token submitted in POST data.
     * Terminates with 403 on failure.
     */
    public static function verifyCsrf(): void
    {
        $submitted = $_POST['csrf_token'] ?? '';
        if (!hash_equals(self::csrf(), $submitted)) {
            http_response_code(403);
            exit('Invalid CSRF token.');
        }
    }
}
