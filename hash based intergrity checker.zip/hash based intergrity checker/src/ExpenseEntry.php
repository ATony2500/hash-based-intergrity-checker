<?php

declare(strict_types=1);

namespace ExpenseLedger;

use ExpenseLedger\Exception\ValidationException;

/**
 * Immutable value object representing a single expense record.
 * All fields are required non-empty strings; amount must be a non-negative decimal string.
 */
final class ExpenseEntry
{
    public readonly string $id;
    public readonly string $amount;
    public readonly string $description;
    public readonly string $date;
    public readonly string $category;

    public function __construct(
        string $id,
        string $amount,
        string $description,
        string $date,
        string $category,
    ) {
        self::assertNonEmpty('id', $id);
        self::assertNonEmpty('description', $description);
        self::assertNonEmpty('date', $date);
        self::assertNonEmpty('category', $category);
        self::assertValidAmount($amount);

        $this->id          = $id;
        $this->amount      = $amount;
        $this->description = $description;
        $this->date        = $date;
        $this->category    = $category;
    }

    // -------------------------------------------------------------------------
    // Validation helpers
    // -------------------------------------------------------------------------

    private static function assertNonEmpty(string $field, string $value): void
    {
        if ($value === '') {
            throw new ValidationException("Field '{$field}' must not be empty.");
        }
    }

    /**
     * Amount must be a non-negative decimal string:
     *   - Whole numbers:  "0", "123"
     *   - Decimals:       "0.50", "123.45"
     *   - No leading zeros (except "0" itself or "0.xx")
     *   - No negative sign
     */
    private static function assertValidAmount(string $amount): void
    {
        if ($amount === '') {
            throw new ValidationException("Field 'amount' must not be empty.");
        }

        // Pattern: optional leading digits, optional decimal part
        // Valid:   0, 123, 0.5, 123.45
        // Invalid: -1, .5, 1., 1.2.3, abc
        if (!preg_match('/^\d+(\.\d+)?$/', $amount)) {
            throw new ValidationException(
                "Field 'amount' must be a non-negative decimal string (e.g. \"0\", \"123\", \"123.45\"); got \"{$amount}\"."
            );
        }
    }
}
