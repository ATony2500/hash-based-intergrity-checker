<?php
declare(strict_types=1);
namespace ExpenseLedger;

/**
 * MySQL-backed user registration and authentication.
 */
final class AuthStore
{
    private \PDO $pdo;

    public function __construct()
    {
        $this->pdo = Database::connect();
    }

    public function register(
        string $username,
        string $email,
        string $password,
        string $role = 'user'
    ): int {
        $username = trim($username);
        $email    = trim($email);

        if (strlen($username) < 3 || strlen($username) > 50) {
            throw new \RuntimeException('Username must be 3–50 characters.');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new \RuntimeException('Invalid email address.');
        }
        if (strlen($password) < 8) {
            throw new \RuntimeException('Password must be at least 8 characters.');
        }
        if (!in_array($role, ['admin', 'user'], true)) {
            throw new \RuntimeException('Invalid role.');
        }

        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);

        try {
            $stmt = $this->pdo->prepare(
                "INSERT INTO users (username, email, password_hash, role)
                 VALUES (:u, :e, :h, :r)"
            );
            $stmt->execute([':u' => $username, ':e' => $email, ':h' => $hash, ':r' => $role]);
        } catch (\PDOException $ex) {
            // MySQL error 1062 = duplicate entry
            if ($ex->getCode() === '23000') {
                throw new \RuntimeException('Username or email already taken.');
            }
            throw $ex;
        }

        return (int) $this->pdo->lastInsertId();
    }

    public function attempt(string $username, string $password): ?array
    {
        $username = trim($username);

        if ($this->isLockedOut($username)) {
            throw new \RuntimeException('Too many failed attempts. Please wait 60 seconds.');
        }

        $stmt = $this->pdo->prepare(
            'SELECT * FROM users WHERE username = :u LIMIT 1'
        );
        $stmt->execute([':u' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $this->recordAttempt($username, true);
            if (password_needs_rehash($user['password_hash'], PASSWORD_BCRYPT, ['cost' => 12])) {
                $this->updateHash((int) $user['id'], $password);
            }
            return $user;
        }

        $this->recordAttempt($username, false);
        return null;
    }

    private function isLockedOut(string $username): bool
    {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(*) FROM login_attempts
             WHERE username = :u AND success = 0
               AND attempted_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)"
        );
        $stmt->execute([':u' => $username]);
        if ((int) $stmt->fetchColumn() < 5) {
            return false;
        }

        $stmt2 = $this->pdo->prepare(
            "SELECT attempted_at FROM login_attempts
             WHERE username = :u AND success = 0
             ORDER BY id DESC LIMIT 1"
        );
        $stmt2->execute([':u' => $username]);
        $last = $stmt2->fetchColumn();
        return $last && (time() - strtotime($last)) < 60;
    }

    private function recordAttempt(string $username, bool $success): void
    {
        $stmt = $this->pdo->prepare(
            "INSERT INTO login_attempts (username, success) VALUES (:u, :s)"
        );
        $stmt->execute([':u' => $username, ':s' => $success ? 1 : 0]);
    }

    private function updateHash(int $id, string $password): void
    {
        $stmt = $this->pdo->prepare('UPDATE users SET password_hash = :h WHERE id = :id');
        $stmt->execute([
            ':h'  => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
            ':id' => $id,
        ]);
    }

    public function findById(int $id): ?array
    {
        $stmt = $this->pdo->prepare('SELECT * FROM users WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public function allUsers(): array
    {
        return $this->pdo
            ->query('SELECT id, username, email, role, created_at FROM users ORDER BY id ASC')
            ->fetchAll();
    }
}
