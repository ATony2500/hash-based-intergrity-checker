<?php

declare(strict_types=1);

namespace ExpenseLedger;

use ExpenseLedger\HasherInterface;

/**
 * Mutable append-only aggregate that maintains an ordered list of HashedEntry records.
 *
 * Each appended entry is hashed against the previous entry's hash (or ZERO_HASH for
 * the genesis entry), forming a tamper-evident chain.
 */
final class Ledger
{
    /** @var HashedEntry[] */
    private array $hashedEntries = [];

    public function __construct(private readonly HasherInterface $hasher) {}

    /**
     * Hash and append an ExpenseEntry to the ledger.
     *
     * @param ExpenseEntry $entry The entry to append.
     * @return HashedEntry        The newly created hashed entry.
     */
    public function append(ExpenseEntry $entry): HashedEntry
    {
        $prevHash = empty($this->hashedEntries)
            ? HasherInterface::ZERO_HASH
            : end($this->hashedEntries)->entry_hash;

        $entryHash   = $this->hasher->hashEntry($entry, $prevHash);
        $hashedEntry = new HashedEntry($entry, $entryHash, $prevHash);

        $this->hashedEntries[] = $hashedEntry;

        return $hashedEntry;
    }

    /**
     * Restore a HashedEntry from persistent storage without recomputing the hash.
     * Use this when loading an existing chain from the database.
     */
    public function restore(HashedEntry $he): void
    {
        $this->hashedEntries[] = $he;
    }

    /**
     * Look up a HashedEntry by its entry id.
     * @return HashedEntry|null The matching entry, or null if not found.
     */
    public function get(string $id): ?HashedEntry
    {
        foreach ($this->hashedEntries as $hashedEntry) {
            if ($hashedEntry->entry->id === $id) {
                return $hashedEntry;
            }
        }

        return null;
    }

    /**
     * Return the ordered list of all HashedEntry records.
     *
     * @return HashedEntry[]
     */
    public function entries(): array
    {
        return $this->hashedEntries;
    }
}
