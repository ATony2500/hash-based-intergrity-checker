# Requirements Document

## Introduction

This document defines requirements for a hash-based integrity checker for an expense ledger. The system uses cryptographic hashing and hash chaining to detect tampering in expense records. Any modification to a past entry — whether to amounts, descriptions, dates, or metadata — will be detectable by verifying the chain of hashes. The system supports both full-ledger verification and targeted single-entry verification.

## Glossary

- **Expense_Entry**: A single record in the ledger containing fields such as amount, description, date, category, and a unique identifier.
- **Entry_Hash**: A cryptographic hash (SHA-256) computed over the canonical serialization of an Expense_Entry combined with the hash of the preceding entry.
- **Ledger**: An ordered, append-only sequence of Expense_Entries, each linked to the previous via its Entry_Hash.
- **Chain**: The sequence of Entry_Hashes that links all entries from the genesis entry to the most recent entry.
- **Genesis_Entry**: The first entry in the Ledger, whose preceding hash is a well-known zero value.
- **Integrity_Report**: A structured result produced by the Verifier describing the outcome of a verification operation, including any detected tampered entries.
- **Hasher**: The component responsible for computing Entry_Hashes.
- **Verifier**: The component responsible for verifying the integrity of the Ledger or individual entries.
- **Serializer**: The component responsible for producing a canonical byte representation of an Expense_Entry for hashing.
- **Tampered_Entry**: An Expense_Entry whose recomputed Entry_Hash does not match the stored Entry_Hash.

## Requirements

### Requirement 1: Expense Entry Hashing

**User Story:** As a financial auditor, I want each expense entry to have a cryptographic hash, so that I can detect any modification to individual records.

#### Acceptance Criteria

1. WHEN an Expense_Entry is added to the Ledger, THE Hasher SHALL compute an Entry_Hash using SHA-256 over the canonical serialization of the entry combined with the Entry_Hash of the immediately preceding entry.
2. THE Serializer SHALL produce a deterministic, canonical byte representation of an Expense_Entry that includes all fields: identifier, amount, description, date, and category.
3. WHEN the Genesis_Entry is hashed, THE Hasher SHALL use a well-known zero value (32 zero bytes) as the preceding Entry_Hash.
4. THE Hasher SHALL store the computed Entry_Hash alongside the Expense_Entry in the Ledger.

### Requirement 2: Hash Chaining

**User Story:** As a financial auditor, I want expense entries to be cryptographically chained, so that modifying any past entry breaks the chain and is detectable.

#### Acceptance Criteria

1. THE Ledger SHALL maintain an ordered sequence of entries where each entry's Entry_Hash incorporates the Entry_Hash of the preceding entry.
2. WHEN a new Expense_Entry is appended to the Ledger, THE Hasher SHALL incorporate the Entry_Hash of the current last entry as input to the new entry's hash computation.
3. THE Ledger SHALL preserve the insertion order of entries such that the chain reflects the order in which entries were added.
4. WHEN the Ledger is serialized to persistent storage, THE Serializer SHALL encode the full chain including all Entry_Hashes in a format that can be round-tripped without loss.

### Requirement 3: Full Ledger Verification

**User Story:** As a financial auditor, I want to verify the integrity of the entire ledger in one operation, so that I can confirm no entries have been tampered with.

#### Acceptance Criteria

1. WHEN a verification is requested on the full Ledger, THE Verifier SHALL recompute the Entry_Hash for every entry and compare it against the stored Entry_Hash.
2. WHEN all recomputed Entry_Hashes match their stored counterparts, THE Verifier SHALL return an Integrity_Report indicating the Ledger is intact.
3. WHEN one or more recomputed Entry_Hashes do not match their stored counterparts, THE Verifier SHALL return an Integrity_Report that identifies each Tampered_Entry by its identifier and position in the Ledger.
4. THE Verifier SHALL verify entries in chain order, starting from the Genesis_Entry.

### Requirement 4: Single Entry Verification

**User Story:** As a financial auditor, I want to verify the integrity of a specific expense entry, so that I can quickly check a targeted record without scanning the full ledger.

#### Acceptance Criteria

1. WHEN a verification is requested for a specific Expense_Entry by identifier, THE Verifier SHALL recompute the Entry_Hash for that entry using the stored preceding Entry_Hash and compare it against the stored Entry_Hash.
2. WHEN the recomputed Entry_Hash matches the stored Entry_Hash, THE Verifier SHALL return an Integrity_Report indicating that entry is intact.
3. WHEN the recomputed Entry_Hash does not match the stored Entry_Hash, THE Verifier SHALL return an Integrity_Report indicating that entry is tampered.
4. IF an identifier is provided that does not exist in the Ledger, THEN THE Verifier SHALL return an error indicating the entry was not found.

### Requirement 5: Tamper Detection and Reporting

**User Story:** As a financial auditor, I want tamper detection to identify exactly which entries were modified, so that I can investigate and remediate specific records.

#### Acceptance Criteria

1. WHEN the Verifier detects a Tampered_Entry, THE Integrity_Report SHALL include the entry's identifier, its position in the chain, and the expected versus actual Entry_Hash values.
2. WHEN a Tampered_Entry is detected at position N, THE Verifier SHALL continue verifying subsequent entries and report all entries whose stored Entry_Hash does not match the recomputed value.
3. WHEN no tampering is detected, THE Integrity_Report SHALL include a count of verified entries and a status of "intact".
4. WHEN tampering is detected, THE Integrity_Report SHALL include a count of tampered entries and a status of "tampered".

### Requirement 6: Ledger Serialization and Persistence

**User Story:** As a developer, I want the ledger to be serializable to and from a persistent format, so that integrity can be verified after the ledger is stored and reloaded.

#### Acceptance Criteria

1. THE Serializer SHALL encode the Ledger to a JSON format that includes all Expense_Entries and their associated Entry_Hashes.
2. WHEN a Ledger is decoded from JSON, THE Serializer SHALL reconstruct the full chain including all Entry_Hashes.
3. FOR ALL valid Ledger instances, encoding then decoding SHALL produce a Ledger equivalent to the original (round-trip property).
4. IF the JSON input is malformed or missing required fields, THEN THE Serializer SHALL return a descriptive error.

### Requirement 7: Error Handling

**User Story:** As a developer, I want the system to handle invalid inputs gracefully, so that errors are surfaced clearly without crashing.

#### Acceptance Criteria

1. IF an Expense_Entry is missing required fields (identifier, amount, description, date, or category), THEN THE Hasher SHALL return a descriptive error and not modify the Ledger.
2. IF the Ledger is empty, THEN THE Verifier SHALL return an Integrity_Report indicating zero entries verified and a status of "intact".
3. IF a hash computation fails due to an internal error, THEN THE Hasher SHALL return a descriptive error identifying the failed operation.
