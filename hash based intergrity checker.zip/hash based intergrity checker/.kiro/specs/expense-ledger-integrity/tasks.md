# Implementation Plan: Expense Ledger Integrity

## Overview

Implement a PHP library for tamper-evident expense ledger management using SHA-256 hash chaining. The library exposes `ExpenseEntry`, `HashedEntry`, `Ledger`, `Hasher`, `Serializer`, and `Verifier` classes. Property-based tests use the `eris` library (PHP). A lightweight JavaScript module wraps the JSON serialization format for any JS consumers.

## Tasks

- [x] 1. Set up project structure and dependencies
  - Initialize `composer.json` with `eris/eris` (property-based testing) and `phpunit/phpunit`
  - Create `src/` directory with namespace `ExpenseLedger`
  - Create `tests/` directory for unit and property tests
  - Configure `phpunit.xml`
  - _Requirements: all_

- [x] 2. Implement `ExpenseEntry` and `HashedEntry` data models
  - [x] 2.1 Implement `ExpenseEntry` class with required fields: `id`, `amount`, `description`, `date`, `category`
    - Validate all fields are non-empty strings; `amount` must be a non-negative decimal string
    - Throw typed `ValidationException` on invalid input
    - _Requirements: 1.1, 7.1_
  - [x] 2.2 Write unit tests for `ExpenseEntry` validation
    - Test each missing/empty field triggers `ValidationException`
    - Test valid entry construction succeeds
    - _Requirements: 7.1_
  - [x] 2.3 Implement `HashedEntry` as a value object wrapping `ExpenseEntry` + `entry_hash` + `prev_hash`
    - _Requirements: 1.4_

- [x] 3. Implement `Serializer` — canonical bytes and JSON codec
  - [x] 3.1 Implement `Serializer::canonicalBytes(ExpenseEntry): string`
    - Encode each field as `uint32_big_endian(strlen(field)) . field` in fixed order: id, amount, description, date, category
    - _Requirements: 1.2_
  - [x] 3.2 Write property test for canonical serialization injectivity
    - **Property 1: Canonical serialization is injective**
    - Generate pairs of distinct `ExpenseEntry` values; assert `canonicalBytes` results differ
    - `// Feature: expense-ledger-integrity, Property 1: Canonical serialization is injective`
    - _Requirements: 1.2_
  - [x] 3.3 Implement `Serializer::encodeLedger(Ledger): string` — JSON output
    - Include all `HashedEntry` fields: entry fields + `entry_hash` + `prev_hash`
    - Store `amount` as decimal string
    - _Requirements: 6.1_
  - [x] 3.4 Implement `Serializer::decodeLedger(string): Ledger`
    - Reconstruct full chain from JSON; throw typed `ParseException` on malformed input or missing fields
    - _Requirements: 6.2, 6.4_
  - [x] 3.5 Write property test for ledger serialization round-trip
    - **Property 4: Ledger serialization round-trip**
    - Generate random valid ledgers; assert `decodeLedger(encodeLedger(ledger))` equals original
    - `// Feature: expense-ledger-integrity, Property 4: Ledger serialization round-trip`
    - _Requirements: 6.3_
  - [x] 3.6 Write unit tests for `Serializer` error cases
    - Test malformed JSON returns `ParseException`
    - Test missing required fields returns `ParseException`
    - _Requirements: 6.4_

- [x] 4. Implement `Hasher`
  - [x] 4.1 Implement `Hasher::hashEntry(ExpenseEntry, string $prevHash): string`
    - Compute `hash('sha256', canonicalBytes(entry) . hex2bin($prevHash), false)`
    - Return lowercase hex string (64 chars)
    - Define `ZERO_HASH` constant as 64 zero hex characters
    - _Requirements: 1.1, 1.3_
  - [x] 4.2 Write unit test for genesis hash (golden test)
    - Compute hash of a known entry with zero prev_hash; assert exact expected value
    - _Requirements: 1.1, 1.3_

- [x] 5. Implement `Ledger`
  - [x] 5.1 Implement `Ledger::append(ExpenseEntry): HashedEntry`
    - Validate entry, compute `prevHash` (zero hash if empty, else last entry's `entry_hash`), call `Hasher::hashEntry`, store `HashedEntry`, return it
    - _Requirements: 1.1, 1.4, 2.1, 2.2, 2.3_
  - [x] 5.2 Implement `Ledger::get(string $id): ?HashedEntry` and `Ledger::entries(): array`
    - _Requirements: 4.1_
  - [x] 5.3 Write property test for hash chaining invariant
    - **Property 2: Hash chaining — each entry embeds its predecessor**
    - Generate random sequences of entries; append all; assert `prev_hash[i] === entry_hash[i-1]` for all `i > 0`
    - `// Feature: expense-ledger-integrity, Property 2: Hash chaining`
    - _Requirements: 2.1, 2.2_
  - [x] 5.4 Write property test for genesis zero hash
    - **Property 3: Genesis entry uses zero hash**
    - Generate any non-empty ledger; assert `entries[0].prev_hash === ZERO_HASH`
    - `// Feature: expense-ledger-integrity, Property 3: Genesis entry uses zero hash`
    - _Requirements: 1.3_
  - [x] 5.5 Write property test for invalid entry rejection
    - **Property 10: Whitespace/invalid entries are rejected**
    - Generate entries with one empty/whitespace field; assert `append` throws and ledger size is unchanged
    - `// Feature: expense-ledger-integrity, Property 10: Invalid entries rejected`
    - _Requirements: 7.1_

- [x] 6. Checkpoint — ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement `Verifier`
  - [x] 7.1 Implement `Verifier::verifyLedger(Ledger): IntegrityReport`
    - Iterate entries in chain order; recompute each hash; collect mismatches into `TamperedEntryInfo` list
    - Return `IntegrityReport` with `status`, `verified_count`, `tampered_entries`
    - Handle empty ledger: return intact report with `verified_count = 0`
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 5.1, 5.2, 5.3, 5.4, 7.2_
  - [x] 7.2 Implement `Verifier::verifyEntry(Ledger, string $id): IntegrityReport`
    - Look up entry by id; throw `NotFoundException` if not found; recompute hash; return single-entry report
    - _Requirements: 4.1, 4.2, 4.3, 4.4_
  - [x] 7.3 Write property test for intact ledger verification
    - **Property 5: Intact ledger verifies cleanly**
    - Generate random ledgers built via `append`; assert `verifyLedger` returns `intact` with zero tampered entries
    - `// Feature: expense-ledger-integrity, Property 5: Intact ledger verifies cleanly`
    - _Requirements: 3.1, 3.2_
  - [x] 7.4 Write property test for single-field mutation detection
    - **Property 6: Single-field mutation is detected**
    - Generate a ledger; pick a random entry and field; mutate it; assert `verifyLedger` returns `tampered` and includes that entry
    - `// Feature: expense-ledger-integrity, Property 6: Single-field mutation is detected`
    - _Requirements: 3.3, 5.1, 5.2_
  - [x] 7.5 Write property test for tamper cascade
    - **Property 7: Tamper detection cascades**
    - Generate a ledger with ≥2 entries; mutate entry at position `i`; assert entries `0..i-1` are intact and position `i` is tampered
    - `// Feature: expense-ledger-integrity, Property 7: Tamper detection cascades`
    - _Requirements: 5.2_
  - [x] 7.6 Write property test for single-entry vs full-ledger agreement
    - **Property 8: Single-entry verification matches full verification**
    - Generate random ledgers (intact and tampered); for each entry assert `verifyEntry` result agrees with `verifyLedger` for that entry
    - `// Feature: expense-ledger-integrity, Property 8: Single-entry matches full verification`
    - _Requirements: 4.1, 4.2, 4.3_
  - [x] 7.7 Write unit tests for `Verifier` edge cases
    - Empty ledger returns intact with `verified_count = 0` (Property 9)
    - Unknown ID throws `NotFoundException`
    - _Requirements: 7.2, 4.4_

- [x] 8. Implement `IntegrityReport` and `TamperedEntryInfo` value objects
  - Simple readonly classes/structs with `status`, `verified_count`, `tampered_entries`
  - `TamperedEntryInfo` holds `id`, `position`, `expected_hash`, `actual_hash`
  - _Requirements: 5.1, 5.3, 5.4_

- [x] 9. Wire everything together via a `LedgerFactory` or top-level facade
  - [x] 9.1 Create a `LedgerFactory::create(): Ledger` convenience method that wires `Hasher` and `Serializer` into a `Ledger` instance
    - _Requirements: all_
  - [x] 9.2 Create a JavaScript module `ledger.js` that wraps `encodeLedger`/`decodeLedger` JSON format for JS consumers
    - Implement `encodeLedger(entries)` and `decodeLedger(json)` matching the PHP JSON schema
    - _Requirements: 6.1, 6.2, 6.3_
  - [x] 9.3 Write JavaScript unit tests for `ledger.js` round-trip
    - Use `fast-check` for property-based round-trip test
    - `// Feature: expense-ledger-integrity, Property 4: Ledger serialization round-trip`
    - _Requirements: 6.3_

- [x] 10. Final checkpoint — ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- All tasks are required — tests run alongside implementation
- `eris/eris` is the PHP property-based testing library; each property test runs ≥100 iterations
- `fast-check` is used for the JavaScript property test in task 9.3
- Amount is always stored and hashed as a decimal string (never float) to avoid precision issues
- All errors are typed exceptions (`ValidationException`, `ParseException`, `NotFoundException`) — not raw strings
