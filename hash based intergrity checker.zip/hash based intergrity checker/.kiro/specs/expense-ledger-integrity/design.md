# Design Document: Expense Ledger Integrity

## Overview

The expense ledger integrity system uses SHA-256 cryptographic hashing with forward chaining to detect tampering in an ordered sequence of expense records. Each entry's hash is computed over its own fields plus the hash of the preceding entry, forming a chain where any modification to a past entry invalidates all subsequent hashes. The design is inspired by blockchain-style hash chaining but is intentionally lightweight — no consensus, no distributed nodes, just a tamper-evident append-only log.

The system is implemented as a pure library with no external service dependencies. It exposes three primary components: a `Hasher` for computing and attaching entry hashes, a `Verifier` for checking integrity, and a `Serializer` for encoding/decoding the ledger to JSON.

## Architecture

```mermaid
graph TD
    A[Client Code] --> B[Ledger]
    B --> C[Hasher]
    B --> D[Verifier]
    B --> E[Serializer]
    C --> F[SHA-256 Hash Function]
    D --> C
    E --> G[JSON Codec]
    B --> H[Entry Store - ordered list]
```

The `Ledger` is the central aggregate. It owns the ordered list of `HashedEntry` records (each being an `ExpenseEntry` plus its computed `EntryHash`). The `Hasher`, `Verifier`, and `Serializer` are stateless components that operate on the `Ledger` data.

## Components and Interfaces

### ExpenseEntry

The raw data record. All fields are required.

```
ExpenseEntry {
  id:          string       // unique identifier (UUID or similar)
  amount:      decimal      // monetary amount, must be non-negative
  description: string       // human-readable description, non-empty
  date:        ISO-8601 date string
  category:    string       // non-empty category label
}
```

### HashedEntry

An `ExpenseEntry` with its computed hash and the preceding hash it was chained against.

```
HashedEntry {
  entry:        ExpenseEntry
  entry_hash:   hex string  // SHA-256 output, 64 hex chars
  prev_hash:    hex string  // the preceding entry's hash (or zero hash for genesis)
}
```

### Ledger

The ordered collection of `HashedEntry` records.

```
Ledger {
  entries: List<HashedEntry>   // ordered by insertion
}
```

Operations:
- `append(entry: ExpenseEntry) -> Result<HashedEntry, Error>` — hashes and appends
- `get(id: string) -> Option<HashedEntry>` — lookup by entry id
- `entries() -> List<HashedEntry>` — read-only ordered view

### Hasher

Stateless. Computes `EntryHash = SHA-256(canonical_bytes(entry) || prev_hash_bytes)`.

```
Hasher {
  hash_entry(entry: ExpenseEntry, prev_hash: bytes[32]) -> Result<bytes[32], Error>
}
```

The canonical serialization concatenates fields in a fixed order with length-prefixed encoding to avoid ambiguity (e.g., `"10"` + `"0"` must not collide with `"1"` + `"00"`).

### Serializer

Stateless. Handles canonical byte serialization for hashing and JSON encoding/decoding for persistence.

```
Serializer {
  canonical_bytes(entry: ExpenseEntry) -> Result<bytes, Error>
  encode_ledger(ledger: Ledger) -> Result<string, Error>   // JSON
  decode_ledger(json: string) -> Result<Ledger, Error>
}
```

### Verifier

Stateless. Recomputes hashes and compares against stored values.

```
Verifier {
  verify_ledger(ledger: Ledger) -> IntegrityReport
  verify_entry(ledger: Ledger, id: string) -> Result<IntegrityReport, Error>
}
```

### IntegrityReport

```
IntegrityReport {
  status:           "intact" | "tampered"
  verified_count:   integer
  tampered_entries: List<TamperedEntryInfo>   // empty if intact
}

TamperedEntryInfo {
  id:             string
  position:       integer   // 0-based index in chain
  expected_hash:  hex string
  actual_hash:    hex string
}
```

## Data Models

### Hash Computation

For entry at position `i`:

```
prev_hash_i = zero_hash                    if i == 0
prev_hash_i = entry_hash_{i-1}             if i > 0

entry_hash_i = SHA-256(canonical_bytes(entry_i) || prev_hash_i)
```

The zero hash is 32 zero bytes (`0x00 * 32`), represented as 64 zero hex characters.

### Canonical Serialization

To avoid hash collisions from field concatenation, each field is length-prefixed:

```
canonical_bytes(entry) =
  len_prefix(entry.id)          ||
  len_prefix(entry.amount)      ||   // decimal string, e.g. "123.45"
  len_prefix(entry.description) ||
  len_prefix(entry.date)        ||
  len_prefix(entry.category)

len_prefix(s) = uint32_big_endian(len(s)) || utf8_bytes(s)
```

This ensures `canonical_bytes` is injective — no two distinct entries produce the same byte sequence.

### JSON Ledger Format

```json
{
  "entries": [
    {
      "id": "...",
      "amount": "123.45",
      "description": "...",
      "date": "2024-01-15",
      "category": "...",
      "entry_hash": "abcd...ef",
      "prev_hash": "0000...00"
    }
  ]
}
```

Amount is stored as a decimal string to avoid floating-point precision issues.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Canonical serialization is injective

*For any* two distinct `ExpenseEntry` values, their canonical byte representations must differ.

This ensures that no two different entries hash to the same value due to serialization ambiguity.

**Validates: Requirements 1.2**

---

### Property 2: Hash chaining — each entry embeds its predecessor

*For any* `Ledger` with at least two entries, for every entry at position `i > 0`, the `prev_hash` field stored in `HashedEntry[i]` must equal the `entry_hash` field of `HashedEntry[i-1]`.

**Validates: Requirements 2.1, 2.2**

---

### Property 3: Genesis entry uses zero hash

*For any* `Ledger` with at least one entry, the `prev_hash` of the entry at position 0 must equal the 64-character zero hex string.

**Validates: Requirements 1.3**

---

### Property 4: Ledger serialization round-trip

*For any* valid `Ledger`, encoding it to JSON and then decoding the result must produce a `Ledger` equivalent to the original (same entries, same hashes, same order).

**Validates: Requirements 6.3**

---

### Property 5: Intact ledger verifies cleanly

*For any* `Ledger` constructed by appending entries through the normal `append` operation, `verify_ledger` must return an `IntegrityReport` with status `"intact"` and zero tampered entries.

**Validates: Requirements 3.1, 3.2**

---

### Property 6: Single-field mutation is detected

*For any* `Ledger` with at least one entry, mutating any single field of any `HashedEntry.entry` (without recomputing the hash) must cause `verify_ledger` to return status `"tampered"` and include that entry in `tampered_entries`.

This is the core tamper-detection property. It covers all fields: id, amount, description, date, category.

**Validates: Requirements 3.3, 5.1, 5.2**

---

### Property 7: Tamper detection cascades

*For any* `Ledger` with at least two entries, mutating the entry at position `i` (without recomputing hashes) must cause `verify_ledger` to report position `i` as tampered. Entries at positions `0` through `i-1` that were not mutated must remain intact.

This validates that the chain correctly isolates the first point of corruption.

**Validates: Requirements 5.2**

---

### Property 8: Single-entry verification matches full verification

*For any* `Ledger` and any entry `e` in that ledger, the result of `verify_entry(ledger, e.id)` must agree with the result for that entry in `verify_ledger(ledger)`.

**Validates: Requirements 4.1, 4.2, 4.3**

---

### Property 9: Empty ledger verifies as intact

*For any* empty `Ledger`, `verify_ledger` must return status `"intact"` with `verified_count = 0`.

This is an edge case of Property 5 but important enough to call out explicitly.

**Validates: Requirements 7.2**

---

### Property 10: Whitespace/invalid entries are rejected

*For any* `ExpenseEntry` with a missing or empty required field, `append` must return an error and the `Ledger` must remain unchanged.

**Validates: Requirements 7.1**

## Error Handling

| Scenario | Component | Behavior |
|---|---|---|
| Missing required field on entry | Hasher | Return descriptive error, do not modify ledger |
| Entry ID not found | Verifier | Return `NotFound` error |
| Empty ledger verification | Verifier | Return intact report with 0 entries |
| Malformed JSON on decode | Serializer | Return descriptive parse error |
| Missing fields in JSON | Serializer | Return descriptive field error |
| Internal hash failure | Hasher | Return descriptive error |

All errors are typed (not stringly-typed) to allow callers to handle them programmatically.

## Testing Strategy

### Dual Testing Approach

Both unit tests and property-based tests are required. They are complementary:

- Unit tests cover specific examples, edge cases, and error conditions
- Property tests verify universal correctness across randomly generated inputs

### Property-Based Testing

Use a property-based testing library appropriate for the chosen implementation language (e.g., `hypothesis` for Python, `fast-check` for TypeScript, `QuickCheck` for Haskell, `proptest` for Rust).

Each property test must run a minimum of 100 iterations. Each test must be tagged with a comment referencing the design property it validates:

```
// Feature: expense-ledger-integrity, Property 4: Ledger serialization round-trip
```

Properties to implement as property-based tests:
- Property 1: Canonical serialization is injective
- Property 2: Hash chaining — each entry embeds its predecessor
- Property 3: Genesis entry uses zero hash
- Property 4: Ledger serialization round-trip
- Property 5: Intact ledger verifies cleanly
- Property 6: Single-field mutation is detected
- Property 7: Tamper detection cascades
- Property 8: Single-entry verification matches full verification
- Property 9: Empty ledger verifies as intact (edge case, covered by generator)
- Property 10: Whitespace/invalid entries are rejected

### Unit Tests

Unit tests should cover:
- Specific known hash values (golden tests) to catch algorithm regressions
- Error message content for each error condition
- Boundary values: single-entry ledger, two-entry ledger
- Amount formatting edge cases (zero, large values, many decimal places)
