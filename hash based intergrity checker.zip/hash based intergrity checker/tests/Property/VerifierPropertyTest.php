<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Property;

use Eris\Generator;
use Eris\TestTrait;
use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\HashedEntry;
use ExpenseLedger\Hasher;
use ExpenseLedger\Ledger;
use ExpenseLedger\Serializer;
use ExpenseLedger\TamperedEntryInfo;
use ExpenseLedger\Verifier;
use PHPUnit\Framework\TestCase;

class VerifierPropertyTest extends TestCase
{
    use TestTrait;

    protected function getTestCaseAnnotations(): array { return []; }
    public function erisTeardown(): void {}

    private function nonEmptyString()
    {
        return Generator\map(fn(string $s): string => 'a' . $s, Generator\string());
    }

    private function amountString()
    {
        return Generator\map(fn(int $n): string => (string) $n, Generator\nat());
    }

    private function entryGen()
    {
        $ne = $this->nonEmptyString();
        $am = $this->amountString();
        return Generator\bind($ne, fn(string $id) =>
            Generator\bind($am, fn(string $amount) =>
                Generator\bind($ne, fn(string $description) =>
                    Generator\bind($ne, fn(string $date) =>
                        Generator\map(
                            fn(string $category) => new ExpenseEntry($id, $amount, $description, $date, $category),
                            $ne
                        )
                    )
                )
            )
        );
    }

    private function nonEmptyEntriesGen()
    {
        return Generator\bind(Generator\choose(1, 5), fn(int $n) => Generator\vector($n, $this->entryGen()));
    }

    private function atLeastTwoEntriesGen()
    {
        return Generator\bind(Generator\choose(2, 5), fn(int $n) => Generator\vector($n, $this->entryGen()));
    }

    private function makeComponents(): array
    {
        $serializer = new Serializer();
        $hasher     = new Hasher($serializer);
        return [new Ledger($hasher), new Verifier($hasher)];
    }

    /**
     * // Feature: expense-ledger-integrity, Property 5: Intact ledger verifies cleanly
     * Validates: Requirements 3.1, 3.2
     */
    public function testIntactLedgerVerifiesCleanly(): void
    {
        $this->forAll($this->nonEmptyEntriesGen())
            ->then(function (array $entries): void {
                [$ledger, $verifier] = $this->makeComponents();
                foreach ($entries as $entry) { $ledger->append($entry); }
                $report = $verifier->verifyLedger($ledger);
                $this->assertSame('intact', $report->status);
                $this->assertCount(0, $report->tampered_entries);
                $this->assertSame(count($entries), $report->verified_count);
            });
    }

    /**
     * // Feature: expense-ledger-integrity, Property 6: Single-field mutation is detected
     * Validates: Requirements 3.3, 5.1, 5.2
     */
    public function testSingleFieldMutationIsDetected(): void
    {
        $this->forAll($this->nonEmptyEntriesGen(), Generator\choose(0, 4))
            ->then(function (array $entries, int $fieldIndex): void {
                [$ledger, $verifier] = $this->makeComponents();
                foreach ($entries as $entry) { $ledger->append($entry); }

                $hashedEntries = $ledger->entries();
                $targetIndex   = count($hashedEntries) - 1;
                $targetHashed  = $hashedEntries[$targetIndex];
                $original      = $targetHashed->entry;

                $fields = [$original->id, $original->amount, $original->description, $original->date, $original->category];
                $fields[$fieldIndex] = ($fieldIndex === 1) ? $original->amount . '0' : $fields[$fieldIndex] . 'MUTATED';

                $mutated    = new ExpenseEntry($fields[0], $fields[1], $fields[2], $fields[3], $fields[4]);
                $newEntries = $hashedEntries;
                $newEntries[$targetIndex] = new HashedEntry($mutated, $targetHashed->entry_hash, $targetHashed->prev_hash);

                $fakeLedger = new class($newEntries) {
                    public function __construct(private array $e) {}
                    public function entries(): array { return $this->e; }
                };

                $report      = $verifier->verifyLedger($fakeLedger);
                $this->assertSame('tampered', $report->status);
                $tamperedIds = array_map(fn(TamperedEntryInfo $t) => $t->id, $report->tampered_entries);
                $this->assertContains($fields[0], $tamperedIds);
            });
    }

    /**
     * // Feature: expense-ledger-integrity, Property 7: Tamper detection cascades
     * Validates: Requirements 5.2
     */
    public function testTamperDetectionCascades(): void
    {
        $this->forAll($this->atLeastTwoEntriesGen())
            ->then(function (array $entries): void {
                [$ledger, $verifier] = $this->makeComponents();
                foreach ($entries as $entry) { $ledger->append($entry); }

                $hashedEntries = $ledger->entries();
                $original      = $hashedEntries[0]->entry;
                $mutated       = new ExpenseEntry($original->id, '1', $original->description . 'X', $original->date, $original->category);

                $newEntries    = $hashedEntries;
                $newEntries[0] = new HashedEntry($mutated, $hashedEntries[0]->entry_hash, $hashedEntries[0]->prev_hash);

                $fakeLedger = new class($newEntries) {
                    public function __construct(private array $e) {}
                    public function entries(): array { return $this->e; }
                };

                $report = $verifier->verifyLedger($fakeLedger);
                $this->assertSame('tampered', $report->status);
                $positions = array_map(fn(TamperedEntryInfo $t) => $t->position, $report->tampered_entries);
                $this->assertContains(0, $positions);
            });
    }

    /**
     * // Feature: expense-ledger-integrity, Property 8: Single-entry matches full verification
     * Validates: Requirements 4.1, 4.2, 4.3
     */
    public function testSingleEntryVerificationMatchesFullVerification(): void
    {
        $this->forAll($this->nonEmptyEntriesGen())
            ->then(function (array $entries): void {
                [$ledger, $verifier] = $this->makeComponents();
                foreach ($entries as $entry) { $ledger->append($entry); }

                $fullReport  = $verifier->verifyLedger($ledger);
                $tamperedIds = array_map(fn(TamperedEntryInfo $t) => $t->id, $fullReport->tampered_entries);

                foreach ($ledger->entries() as $hashedEntry) {
                    $id          = $hashedEntry->entry->id;
                    $entryReport = $verifier->verifyEntry($ledger, $id);
                    $this->assertSame(
                        in_array($id, $tamperedIds, true),
                        $entryReport->status === 'tampered',
                        "verifyEntry and verifyLedger must agree on tamper status for entry '{$id}'."
                    );
                }
            });
    }
}
