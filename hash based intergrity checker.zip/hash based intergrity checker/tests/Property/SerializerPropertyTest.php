<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Property;

use Eris\Generator;
use Eris\TestTrait;
use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\HashedEntry;
use ExpenseLedger\Serializer;
use PHPUnit\Framework\TestCase;

// Feature: expense-ledger-integrity, Property 1: Canonical serialization is injective

class SerializerPropertyTest extends TestCase
{
    use TestTrait;

    /**
     * Override to avoid PHPUnit\Util\Test::parseTestMethodAnnotations() which
     * was removed in PHPUnit 10. Eris only uses annotations for optional
     * configuration (@eris-repeat, @eris-ratio, etc.) so returning an empty
     * array is safe — defaults (100 iterations, 50% ratio) will be used.
     */
    protected function getTestCaseAnnotations(): array
    {
        return [];
    }

    /**
     * Override eris teardown to avoid calling hasFailed() which was removed
     * in PHPUnit 10. The seed-dumping behaviour is only needed for debugging
     * failures, so we can safely no-op this in the test suite.
     */
    public function erisTeardown(): void
    {
        // no-op: hasFailed() was removed in PHPUnit 10
    }

    /**
     * Property 1: Canonical serialization is injective.
     *
     * For any two distinct ExpenseEntry values, their canonical byte
     * representations must differ.
     *
     * Strategy: generate a base entry, then generate a non-empty suffix to
     * append to its `id` field — this guarantees the two entries are always
     * distinct without any filtering/skipping.
     *
     * Validates: Requirements 1.2
     */
    public function testCanonicalSerializationIsInjective(): void
    {
        $serializer = new Serializer();

        // Generator that always produces a non-empty string by prepending "a"
        $nonEmptyString = Generator\map(
            fn(string $s): string => 'a' . $s,
            Generator\string()
        );

        // Generator for a valid amount string: natural number as string (e.g. "0", "42")
        $amountString = Generator\map(
            fn(int $n): string => (string) $n,
            Generator\nat()
        );

        // Generator for a non-empty suffix (at least one char "x" prepended)
        $nonEmptySuffix = Generator\map(
            fn(string $s): string => 'x' . $s,
            Generator\string()
        );

        $this->forAll(
            $nonEmptyString,  // id
            $amountString,    // amount
            $nonEmptyString,  // description
            $nonEmptyString,  // date
            $nonEmptyString,  // category
            $nonEmptySuffix   // suffix appended to id to create a guaranteed-different second entry
        )->then(function (
            string $id,
            string $amount,
            string $description,
            string $date,
            string $category,
            string $suffix
        ) use ($serializer): void {
            $entryA = new ExpenseEntry($id, $amount, $description, $date, $category);
            // Append suffix to id — guarantees entryB.id !== entryA.id, so entries are distinct
            $entryB = new ExpenseEntry($id . $suffix, $amount, $description, $date, $category);

            $bytesA = $serializer->canonicalBytes($entryA);
            $bytesB = $serializer->canonicalBytes($entryB);

            $this->assertNotEquals(
                $bytesA,
                $bytesB,
                "Distinct entries must produce distinct canonical bytes.\n"
                . "Entry A id: {$id}\n"
                . "Entry B id: {$id}{$suffix}"
            );
        });
    }

    /**
     * Property 4: Ledger serialization round-trip.
     *
     * For any valid Ledger, encoding it to JSON and then decoding the result
     * must produce a Ledger equivalent to the original (same entries, same
     * hashes, same order).
     *
     * Strategy: generate 0–5 entries with valid field values; compute hashes
     * manually using the same SHA-256 + canonical-bytes logic to build a
     * consistent HashedEntry chain; wrap in an anonymous ledger object; call
     * encodeLedger then decodeLedger; assert field-by-field equality.
     *
     * // Feature: expense-ledger-integrity, Property 4: Ledger serialization round-trip
     *
     * Validates: Requirements 6.3
     */
    public function testLedgerSerializationRoundTrip(): void
    {
        $serializer = new Serializer();

        // Non-empty string generator
        $nonEmptyString = Generator\map(
            fn(string $s): string => 'a' . $s,
            Generator\string()
        );

        // Valid amount: natural number as string
        $amountString = Generator\map(
            fn(int $n): string => (string) $n,
            Generator\nat()
        );

        // Generator for a single ExpenseEntry (5-tuple)
        $entryGen = Generator\bind(
            $nonEmptyString,
            fn(string $id) => Generator\bind(
                $amountString,
                fn(string $amount) => Generator\bind(
                    $nonEmptyString,
                    fn(string $description) => Generator\bind(
                        $nonEmptyString,
                        fn(string $date) => Generator\map(
                            fn(string $category) => new ExpenseEntry($id, $amount, $description, $date, $category),
                            $nonEmptyString
                        )
                    )
                )
            )
        );

        // Generator for a list of 0–5 ExpenseEntry values
        $entriesGen = Generator\bind(
            Generator\choose(0, 5),
            fn(int $count) => Generator\vector($count, $entryGen)
        );

        $this->forAll($entriesGen)->then(function (array $expenseEntries) use ($serializer): void {
            // Build a valid HashedEntry chain by computing hashes manually,
            // mirroring the same logic as Hasher::hashEntry.
            $hashedEntries = [];
            $prevHash = HashedEntry::ZERO_HASH;

            foreach ($expenseEntries as $entry) {
                // Compute entry_hash = SHA-256(canonicalBytes(entry) . hex2bin(prevHash))
                $canonicalBytes = $serializer->canonicalBytes($entry);
                $entryHash = hash('sha256', $canonicalBytes . hex2bin($prevHash), false);

                $hashedEntries[] = new HashedEntry($entry, $entryHash, $prevHash);
                $prevHash = $entryHash;
            }

            // Wrap in an anonymous ledger object with an entries() method
            $ledger = new class($hashedEntries) {
                public function __construct(private array $entries) {}
                public function entries(): array { return $this->entries; }
            };

            // Round-trip: encode then decode
            $json = $serializer->encodeLedger($ledger);
            $decoded = $serializer->decodeLedger($json);

            $decodedEntries = $decoded->entries();

            $this->assertCount(
                count($hashedEntries),
                $decodedEntries,
                'Decoded ledger must have the same number of entries as the original.'
            );

            foreach ($hashedEntries as $i => $original) {
                $restored = $decodedEntries[$i];

                $this->assertSame($original->entry->id,          $restored->entry->id,          "Entry {$i}: id mismatch");
                $this->assertSame($original->entry->amount,      $restored->entry->amount,      "Entry {$i}: amount mismatch");
                $this->assertSame($original->entry->description, $restored->entry->description, "Entry {$i}: description mismatch");
                $this->assertSame($original->entry->date,        $restored->entry->date,        "Entry {$i}: date mismatch");
                $this->assertSame($original->entry->category,    $restored->entry->category,    "Entry {$i}: category mismatch");
                $this->assertSame($original->entry_hash,         $restored->entry_hash,         "Entry {$i}: entry_hash mismatch");
                $this->assertSame($original->prev_hash,          $restored->prev_hash,          "Entry {$i}: prev_hash mismatch");
            }
        });
    }
}
