<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Property;

use Eris\Generator;
use Eris\TestTrait;
use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\Hasher;
use ExpenseLedger\Ledger;
use ExpenseLedger\Serializer;
use ExpenseLedger\Exception\ValidationException;
use PHPUnit\Framework\TestCase;

class LedgerPropertyTest extends TestCase
{
    use TestTrait;

    protected function getTestCaseAnnotations(): array
    {
        return [];
    }

    public function erisTeardown(): void
    {
        // no-op: hasFailed() was removed in PHPUnit 10
    }

    private function nonEmptyString()
    {
        return Generator\map(fn(string $s): string => 'a' . $s, Generator\string());
    }

    private function amountString()
    {
        return Generator\map(fn(int $n): string => (string) $n, Generator\nat());
    }

    private function entryGen()
    {
        $ne = $this->nonEmptyString();
        $am = $this->amountString();
        return Generator\bind($ne, fn(string $id) =>
            Generator\bind($am, fn(string $amount) =>
                Generator\bind($ne, fn(string $description) =>
                    Generator\bind($ne, fn(string $date) =>
                        Generator\map(
                            fn(string $category) => new ExpenseEntry($id, $amount, $description, $date, $category),
                            $ne
                        )
                    )
                )
            )
        );
    }

    private function nonEmptyEntriesGen()
    {
        return Generator\bind(
            Generator\choose(1, 5),
            fn(int $count) => Generator\vector($count, $this->entryGen())
        );
    }

    private function makeLedger(): Ledger
    {
        return new Ledger(new Hasher(new Serializer()));
    }

    /**
     * // Feature: expense-ledger-integrity, Property 2: Hash chaining
     * Validates: Requirements 2.1, 2.2
     */
    public function testHashChainingInvariant(): void
    {
        $this->forAll($this->nonEmptyEntriesGen())
            ->then(function (array $entries): void {
                $ledger = $this->makeLedger();
                foreach ($entries as $entry) {
                    $ledger->append($entry);
                }
                $hashedEntries = $ledger->entries();
                for ($i = 1; $i < count($hashedEntries); $i++) {
                    $this->assertSame(
                        $hashedEntries[$i - 1]->entry_hash,
                        $hashedEntries[$i]->prev_hash,
                        "Hash chaining violated at position {$i}."
                    );
                }
            });
    }

    /**
     * // Feature: expense-ledger-integrity, Property 3: Genesis entry uses zero hash
     * Validates: Requirements 1.3
     */
    public function testGenesisEntryUsesZeroHash(): void
    {
        $this->forAll($this->nonEmptyEntriesGen())
            ->then(function (array $entries): void {
                $ledger = $this->makeLedger();
                foreach ($entries as $entry) {
                    $ledger->append($entry);
                }
                $this->assertSame(
                    Hasher::ZERO_HASH,
                    $ledger->entries()[0]->prev_hash,
                    'Genesis entry must have prev_hash equal to ZERO_HASH.'
                );
            });
    }

    /**
     * // Feature: expense-ledger-integrity, Property 10: Invalid entries rejected
     * Validates: Requirements 7.1
     */
    public function testInvalidEntryIsRejected(): void
    {
        $this->forAll(
            $this->nonEmptyEntriesGen(),
            Generator\choose(0, 4)
        )->then(function (array $validEntries, int $emptyFieldIndex): void {
            $ledger = $this->makeLedger();
            foreach ($validEntries as $entry) {
                $ledger->append($entry);
            }
            $sizeBefore = count($ledger->entries());

            $fields = ['id-x', '10', 'desc', '2024-01-01', 'cat'];
            $fields[$emptyFieldIndex] = '';

            $this->expectException(ValidationException::class);
            try {
                new ExpenseEntry($fields[0], $fields[1], $fields[2], $fields[3], $fields[4]);
            } finally {
                $this->assertSame($sizeBefore, count($ledger->entries()));
            }
        });
    }
}
