<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Unit;

use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\HashedEntry;
use ExpenseLedger\Hasher;
use ExpenseLedger\IntegrityReport;
use ExpenseLedger\Ledger;
use ExpenseLedger\Serializer;
use ExpenseLedger\Verifier;
use ExpenseLedger\Exception\NotFoundException;
use PHPUnit\Framework\TestCase;

final class VerifierTest extends TestCase
{
    private Ledger $ledger;
    private Verifier $verifier;

    protected function setUp(): void
    {
        $hasher         = new Hasher(new Serializer());
        $this->ledger   = new Ledger($hasher);
        $this->verifier = new Verifier($hasher);
    }

    private function makeEntry(string $id = 'e1'): ExpenseEntry
    {
        return new ExpenseEntry($id, '10.00', 'Coffee', '2024-01-15', 'Food');
    }

    // verifyLedger — empty ledger (Property 9 / Requirement 7.2)

    public function testVerifyLedgerEmptyReturnsIntactWithZeroCount(): void
    {
        $report = $this->verifier->verifyLedger($this->ledger);
        $this->assertSame('intact', $report->status);
        $this->assertSame(0, $report->verified_count);
        $this->assertSame([], $report->tampered_entries);
    }

    // verifyLedger — intact

    public function testVerifyLedgerSingleIntactEntry(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $report = $this->verifier->verifyLedger($this->ledger);
        $this->assertSame('intact', $report->status);
        $this->assertSame(1, $report->verified_count);
    }

    public function testVerifyLedgerMultipleIntactEntries(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $this->ledger->append($this->makeEntry('e2'));
        $this->ledger->append($this->makeEntry('e3'));
        $report = $this->verifier->verifyLedger($this->ledger);
        $this->assertSame('intact', $report->status);
        $this->assertSame(3, $report->verified_count);
        $this->assertCount(0, $report->tampered_entries);
    }

    // verifyLedger — tampered

    public function testVerifyLedgerDetectsTamperedEntry(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $this->ledger->append($this->makeEntry('e2'));
        $entries  = $this->ledger->entries();
        $original = $entries[0];

        $mutated    = new ExpenseEntry('e1', '999.00', 'Coffee', '2024-01-15', 'Food');
        $tampered   = new HashedEntry($mutated, $original->entry_hash, $original->prev_hash);
        $fakeLedger = new class([$tampered, $entries[1]]) {
            public function __construct(private array $e) {}
            public function entries(): array { return $this->e; }
        };

        $report = $this->verifier->verifyLedger($fakeLedger);
        $this->assertSame('tampered', $report->status);
        $this->assertSame(2, $report->verified_count);
        $this->assertCount(1, $report->tampered_entries);
        $this->assertSame('e1', $report->tampered_entries[0]->id);
        $this->assertSame(0, $report->tampered_entries[0]->position);
    }

    // verifyEntry — not found

    public function testVerifyEntryThrowsNotFoundExceptionForUnknownId(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $this->expectException(NotFoundException::class);
        $this->verifier->verifyEntry($this->ledger, 'nonexistent');
    }

    public function testVerifyEntryThrowsNotFoundExceptionOnEmptyLedger(): void
    {
        $this->expectException(NotFoundException::class);
        $this->verifier->verifyEntry($this->ledger, 'e1');
    }

    // verifyEntry — intact

    public function testVerifyEntryIntactReturnsIntactReport(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $report = $this->verifier->verifyEntry($this->ledger, 'e1');
        $this->assertSame('intact', $report->status);
        $this->assertSame(1, $report->verified_count);
        $this->assertSame([], $report->tampered_entries);
    }

    // verifyEntry — tampered

    public function testVerifyEntryDetectsTamperedEntry(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $entries  = $this->ledger->entries();
        $original = $entries[0];

        $mutated    = new ExpenseEntry('e1', '500.00', 'Fraud', '2024-01-15', 'Food');
        $fakeLedger = new class([new HashedEntry($mutated, $original->entry_hash, $original->prev_hash)]) {
            public function __construct(private array $e) {}
            public function entries(): array { return $this->e; }
        };

        $report = $this->verifier->verifyEntry($fakeLedger, 'e1');
        $this->assertSame('tampered', $report->status);
        $this->assertSame(1, $report->verified_count);
        $this->assertCount(1, $report->tampered_entries);
        $this->assertSame('e1', $report->tampered_entries[0]->id);
    }
}
