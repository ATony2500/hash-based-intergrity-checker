<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Unit;

use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\HashedEntry;
use ExpenseLedger\Hasher;
use ExpenseLedger\Ledger;
use ExpenseLedger\Serializer;
use ExpenseLedger\Exception\ValidationException;
use PHPUnit\Framework\TestCase;

final class LedgerTest extends TestCase
{
    private Ledger $ledger;

    protected function setUp(): void
    {
        $this->ledger = new Ledger(new Hasher(new Serializer()));
    }

    private function makeEntry(string $id = 'e1'): ExpenseEntry
    {
        return new ExpenseEntry($id, '10.00', 'Coffee', '2024-01-15', 'Food');
    }

    // -------------------------------------------------------------------------
    // append
    // -------------------------------------------------------------------------

    public function testAppendReturnsHashedEntry(): void
    {
        $result = $this->ledger->append($this->makeEntry());

        $this->assertInstanceOf(HashedEntry::class, $result);
    }

    public function testAppendGenesisEntryUsesPrevHashZero(): void
    {
        $result = $this->ledger->append($this->makeEntry());

        $this->assertSame(HashedEntry::ZERO_HASH, $result->prev_hash);
    }

    public function testAppendSecondEntryUsesPrevHashOfFirst(): void
    {
        $first  = $this->ledger->append($this->makeEntry('e1'));
        $second = $this->ledger->append($this->makeEntry('e2'));

        $this->assertSame($first->entry_hash, $second->prev_hash);
    }

    public function testAppendEntryHashIs64CharLowercaseHex(): void
    {
        $result = $this->ledger->append($this->makeEntry());

        $this->assertMatchesRegularExpression('/^[0-9a-f]{64}$/', $result->entry_hash);
    }

    public function testAppendStoresEntryInLedger(): void
    {
        $this->ledger->append($this->makeEntry('e1'));

        $this->assertCount(1, $this->ledger->entries());
    }

    public function testAppendMultipleEntriesPreservesOrder(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $this->ledger->append($this->makeEntry('e2'));
        $this->ledger->append($this->makeEntry('e3'));

        $entries = $this->ledger->entries();
        $this->assertCount(3, $entries);
        $this->assertSame('e1', $entries[0]->entry->id);
        $this->assertSame('e2', $entries[1]->entry->id);
        $this->assertSame('e3', $entries[2]->entry->id);
    }

    // -------------------------------------------------------------------------
    // get
    // -------------------------------------------------------------------------

    public function testGetReturnsNullForEmptyLedger(): void
    {
        $this->assertNull($this->ledger->get('nonexistent'));
    }

    public function testGetReturnsNullForUnknownId(): void
    {
        $this->ledger->append($this->makeEntry('e1'));

        $this->assertNull($this->ledger->get('unknown'));
    }

    public function testGetReturnsCorrectEntry(): void
    {
        $appended = $this->ledger->append($this->makeEntry('e1'));
        $found    = $this->ledger->get('e1');

        $this->assertNotNull($found);
        $this->assertSame($appended->entry_hash, $found->entry_hash);
    }

    public function testGetFindsEntryAmongMultiple(): void
    {
        $this->ledger->append($this->makeEntry('e1'));
        $second = $this->ledger->append($this->makeEntry('e2'));
        $this->ledger->append($this->makeEntry('e3'));

        $found = $this->ledger->get('e2');

        $this->assertNotNull($found);
        $this->assertSame($second->entry_hash, $found->entry_hash);
    }

    // -------------------------------------------------------------------------
    // entries
    // -------------------------------------------------------------------------

    public function testEntriesReturnsEmptyArrayInitially(): void
    {
        $this->assertSame([], $this->ledger->entries());
    }

    public function testEntriesReturnsCopyThatDoesNotMutateLedger(): void
    {
        $this->ledger->append($this->makeEntry('e1'));

        $entries = $this->ledger->entries();
        // Mutating the returned array must not affect the ledger
        array_pop($entries);

        $this->assertCount(1, $this->ledger->entries());
    }
}
