<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Unit;

use ExpenseLedger\DecodedLedger;
use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\HashedEntry;
use ExpenseLedger\Serializer;
use ExpenseLedger\Exception\ParseException;
use PHPUnit\Framework\TestCase;

final class SerializerTest extends TestCase
{
    private Serializer $serializer;

    protected function setUp(): void
    {
        $this->serializer = new Serializer();
    }

    private function makeLedger(array $entries): object
    {
        return new class($entries) {
            public function __construct(private array $items) {}
            public function entries(): array { return $this->items; }
        };
    }

    private function makeHashedEntry(
        string $id, string $amount, string $description,
        string $date, string $category, string $entryHash, string $prevHash,
    ): HashedEntry {
        return new HashedEntry(
            new ExpenseEntry($id, $amount, $description, $date, $category),
            $entryHash, $prevHash,
        );
    }

    // encodeLedger

    public function testEncodeLedgerEmptyLedgerProducesEmptyEntriesArray(): void
    {
        $json = $this->serializer->encodeLedger($this->makeLedger([]));
        $decoded = json_decode($json, true);
        $this->assertSame([], $decoded['entries']);
    }

    public function testEncodeLedgerSingleEntryContainsAllFields(): void
    {
        $zero = HashedEntry::ZERO_HASH;
        $hash = str_repeat('a', 64);
        $ledger = $this->makeLedger([
            $this->makeHashedEntry('id-1', '123.45', 'Lunch', '2024-01-15', 'Food', $hash, $zero),
        ]);
        $row = json_decode($this->serializer->encodeLedger($ledger), true)['entries'][0];
        $this->assertSame('id-1', $row['id']);
        $this->assertSame('123.45', $row['amount']);
        $this->assertSame($hash, $row['entry_hash']);
        $this->assertSame($zero, $row['prev_hash']);
    }

    public function testEncodeLedgerAmountStoredAsDecimalString(): void
    {
        $ledger = $this->makeLedger([
            $this->makeHashedEntry('id-1', '0', 'Zero', '2024-06-01', 'Misc', str_repeat('b', 64), HashedEntry::ZERO_HASH),
        ]);
        $row = json_decode($this->serializer->encodeLedger($ledger), true)['entries'][0];
        $this->assertIsString($row['amount']);
        $this->assertSame('0', $row['amount']);
    }

    public function testEncodeLedgerMultipleEntriesPreservesOrder(): void
    {
        $hash1 = str_repeat('1', 64);
        $hash2 = str_repeat('2', 64);
        $zero  = HashedEntry::ZERO_HASH;
        $ledger = $this->makeLedger([
            $this->makeHashedEntry('id-1', '10.00', 'First',  '2024-01-01', 'A', $hash1, $zero),
            $this->makeHashedEntry('id-2', '20.00', 'Second', '2024-01-02', 'B', $hash2, $hash1),
        ]);
        $entries = json_decode($this->serializer->encodeLedger($ledger), true)['entries'];
        $this->assertSame('id-1', $entries[0]['id']);
        $this->assertSame('id-2', $entries[1]['id']);
        $this->assertSame($hash1, $entries[1]['prev_hash']);
    }

    // decodeLedger — happy path

    public function testDecodeLedgerEmptyEntriesReturnsDecodedLedger(): void
    {
        $result = $this->serializer->decodeLedger('{"entries":[]}');
        $this->assertInstanceOf(DecodedLedger::class, $result);
        $this->assertSame([], $result->entries());
    }

    public function testDecodeLedgerSingleEntryReconstructsCorrectly(): void
    {
        $zero = HashedEntry::ZERO_HASH;
        $hash = str_repeat('a', 64);
        $json = json_encode(['entries' => [[
            'id' => 'id-1', 'amount' => '42.00', 'description' => 'Coffee',
            'date' => '2024-05-01', 'category' => 'Food',
            'entry_hash' => $hash, 'prev_hash' => $zero,
        ]]]);
        $entries = $this->serializer->decodeLedger($json)->entries();
        $this->assertCount(1, $entries);
        $this->assertSame('id-1', $entries[0]->entry->id);
        $this->assertSame($hash, $entries[0]->entry_hash);
    }

    // decodeLedger — error cases

    public function testDecodeLedgerMalformedJsonThrowsParseException(): void
    {
        $this->expectException(ParseException::class);
        $this->expectExceptionMessageMatches('/malformed json/i');
        $this->serializer->decodeLedger('{not valid json');
    }

    public function testDecodeLedgerMissingEntriesKeyThrowsParseException(): void
    {
        $this->expectException(ParseException::class);
        $this->expectExceptionMessageMatches("/missing.*entries/i");
        $this->serializer->decodeLedger('{"foo":"bar"}');
    }

    public function testDecodeLedgerEntriesNotArrayThrowsParseException(): void
    {
        $this->expectException(ParseException::class);
        $this->expectExceptionMessageMatches("/entries.*array/i");
        $this->serializer->decodeLedger('{"entries":"not-an-array"}');
    }

    /** @dataProvider missingFieldProvider */
    public function testDecodeLedgerMissingRequiredFieldThrowsParseException(string $missingField): void
    {
        $this->expectException(ParseException::class);
        $this->expectExceptionMessageMatches("/missing required field '{$missingField}'/i");
        $row = [
            'id' => 'id-1', 'amount' => '10.00', 'description' => 'Test',
            'date' => '2024-01-01', 'category' => 'Cat',
            'entry_hash' => str_repeat('a', 64), 'prev_hash' => HashedEntry::ZERO_HASH,
        ];
        unset($row[$missingField]);
        $this->serializer->decodeLedger(json_encode(['entries' => [$row]]));
    }

    public static function missingFieldProvider(): array
    {
        return [
            ['id'], ['amount'], ['description'], ['date'],
            ['category'], ['entry_hash'], ['prev_hash'],
        ];
    }
}
