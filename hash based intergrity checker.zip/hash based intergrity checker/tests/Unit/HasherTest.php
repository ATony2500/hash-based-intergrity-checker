<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Unit;

use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\Hasher;
use ExpenseLedger\HashedEntry;
use ExpenseLedger\Serializer;
use PHPUnit\Framework\TestCase;

/**
 * Unit tests for Hasher — golden/regression tests for the hash algorithm.
 */
final class HasherTest extends TestCase
{
    private Hasher $hasher;

    protected function setUp(): void
    {
        $this->hasher = new Hasher(new Serializer());
    }

    /**
     * Golden test: hash of a known genesis entry must equal a value computed
     * by the same algorithm implemented inline (without using Hasher).
     *
     * If the Hasher algorithm ever changes, this test will catch the regression
     * because the inline computation and Hasher::hashEntry will diverge.
     *
     * Entry under test:
     *   id          = "test-id"
     *   amount      = "100.00"
     *   description = "Test expense"
     *   date        = "2024-01-01"
     *   category    = "Test"
     *   prev_hash   = ZERO_HASH (64 zero hex chars)
     *
     * Canonical bytes (length-prefixed fields in fixed order):
     *   pack('N', 7)  . "test-id"       => \x00\x00\x00\x07 test-id
     *   pack('N', 6)  . "100.00"        => \x00\x00\x00\x06 100.00
     *   pack('N', 12) . "Test expense"  => \x00\x00\x00\x0c Test expense
     *   pack('N', 10) . "2024-01-01"    => \x00\x00\x00\x0a 2024-01-01
     *   pack('N', 4)  . "Test"          => \x00\x00\x00\x04 Test
     *
     * entry_hash = SHA-256(canonical_bytes . hex2bin(ZERO_HASH))
     *
     * Requirements: 1.1, 1.3
     */
    public function testGenesisHashMatchesInlineComputation(): void
    {
        $entry = new ExpenseEntry(
            id:          'test-id',
            amount:      '100.00',
            description: 'Test expense',
            date:        '2024-01-01',
            category:    'Test',
        );

        // Inline canonical-bytes computation (mirrors Serializer::canonicalBytes)
        $fields = ['test-id', '100.00', 'Test expense', '2024-01-01', 'Test'];
        $canonicalBytes = '';
        foreach ($fields as $field) {
            $canonicalBytes .= pack('N', strlen($field)) . $field;
        }

        // Inline hash computation (mirrors Hasher::hashEntry with ZERO_HASH)
        $prevBytes = hex2bin(HashedEntry::ZERO_HASH);
        $expectedHash = hash('sha256', $canonicalBytes . $prevBytes, false);

        $actualHash = $this->hasher->hashEntry($entry, HashedEntry::ZERO_HASH);

        $this->assertSame($expectedHash, $actualHash);
    }

    /**
     * The genesis hash must be a 64-character lowercase hex string.
     *
     * Requirements: 1.1, 1.3
     */
    public function testGenesisHashIs64CharLowercaseHex(): void
    {
        $entry = new ExpenseEntry(
            id:          'test-id',
            amount:      '100.00',
            description: 'Test expense',
            date:        '2024-01-01',
            category:    'Test',
        );

        $hash = $this->hasher->hashEntry($entry, HashedEntry::ZERO_HASH);

        $this->assertMatchesRegularExpression('/^[0-9a-f]{64}$/', $hash);
    }

    /**
     * Two entries that differ only in one field must produce different hashes,
     * confirming the canonical serialization feeds distinct bytes into SHA-256.
     *
     * Requirements: 1.1
     */
    public function testDifferentEntriesProduceDifferentHashes(): void
    {
        $entry1 = new ExpenseEntry('id-1', '100.00', 'Test expense', '2024-01-01', 'Test');
        $entry2 = new ExpenseEntry('id-2', '100.00', 'Test expense', '2024-01-01', 'Test');

        $hash1 = $this->hasher->hashEntry($entry1, HashedEntry::ZERO_HASH);
        $hash2 = $this->hasher->hashEntry($entry2, HashedEntry::ZERO_HASH);

        $this->assertNotSame($hash1, $hash2);
    }

    /**
     * The same entry hashed against two different prevHash values must produce
     * different results, confirming prevHash is incorporated into the digest.
     *
     * Requirements: 1.1, 1.3
     */
    public function testDifferentPrevHashProducesDifferentHash(): void
    {
        $entry   = new ExpenseEntry('id-1', '50.00', 'Coffee', '2024-03-01', 'Food');
        $prevA   = HashedEntry::ZERO_HASH;
        $prevB   = str_repeat('a', 64);

        $hashA = $this->hasher->hashEntry($entry, $prevA);
        $hashB = $this->hasher->hashEntry($entry, $prevB);

        $this->assertNotSame($hashA, $hashB);
    }
}
