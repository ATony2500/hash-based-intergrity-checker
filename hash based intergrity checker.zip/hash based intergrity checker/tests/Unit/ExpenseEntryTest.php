<?php

declare(strict_types=1);

namespace ExpenseLedger\Tests\Unit;

use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\Exception\ValidationException;
use PHPUnit\Framework\TestCase;

/**
 * Unit tests for ExpenseEntry validation.
 * Requirements: 7.1
 */
final class ExpenseEntryTest extends TestCase
{
    // -------------------------------------------------------------------------
    // Valid construction
    // -------------------------------------------------------------------------

    public function testValidEntryConstructsSuccessfully(): void
    {
        $entry = new ExpenseEntry(
            id: 'abc-123',
            amount: '99.99',
            description: 'Office supplies',
            date: '2024-01-15',
            category: 'Operations',
        );

        $this->assertSame('abc-123', $entry->id);
        $this->assertSame('99.99', $entry->amount);
        $this->assertSame('Office supplies', $entry->description);
        $this->assertSame('2024-01-15', $entry->date);
        $this->assertSame('Operations', $entry->category);
    }

    public function testValidEntryWithWholeNumberAmount(): void
    {
        $entry = new ExpenseEntry('id-1', '0', 'desc', '2024-01-01', 'cat');
        $this->assertSame('0', $entry->amount);
    }

    public function testValidEntryWithLargeDecimalAmount(): void
    {
        $entry = new ExpenseEntry('id-1', '1000000.99', 'desc', '2024-01-01', 'cat');
        $this->assertSame('1000000.99', $entry->amount);
    }

    // -------------------------------------------------------------------------
    // Missing / empty field — each triggers ValidationException
    // -------------------------------------------------------------------------

    public function testEmptyIdThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessageMatches("/id/");

        new ExpenseEntry('', '10.00', 'desc', '2024-01-01', 'cat');
    }

    public function testEmptyAmountThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessageMatches("/amount/");

        new ExpenseEntry('id-1', '', 'desc', '2024-01-01', 'cat');
    }

    public function testEmptyDescriptionThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessageMatches("/description/");

        new ExpenseEntry('id-1', '10.00', '', '2024-01-01', 'cat');
    }

    public function testEmptyDateThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessageMatches("/date/");

        new ExpenseEntry('id-1', '10.00', 'desc', '', 'cat');
    }

    public function testEmptyCategoryThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessageMatches("/category/");

        new ExpenseEntry('id-1', '10.00', 'desc', '2024-01-01', '');
    }

    // -------------------------------------------------------------------------
    // Invalid amount formats
    // -------------------------------------------------------------------------

    public function testNegativeAmountThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);
        $this->expectExceptionMessageMatches("/amount/");

        new ExpenseEntry('id-1', '-5.00', 'desc', '2024-01-01', 'cat');
    }

    public function testAmountWithLeadingDotThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);

        new ExpenseEntry('id-1', '.50', 'desc', '2024-01-01', 'cat');
    }

    public function testAmountWithTrailingDotThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);

        new ExpenseEntry('id-1', '5.', 'desc', '2024-01-01', 'cat');
    }

    public function testAlphaAmountThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);

        new ExpenseEntry('id-1', 'abc', 'desc', '2024-01-01', 'cat');
    }

    public function testAmountWithMultipleDotsThrowsValidationException(): void
    {
        $this->expectException(ValidationException::class);

        new ExpenseEntry('id-1', '1.2.3', 'desc', '2024-01-01', 'cat');
    }
}
