<?php
declare(strict_types=1);
require __DIR__ . '/../vendor/autoload.php';

use ExpenseLedger\Database;

echo "Creating database if missing...\n";
Database::createDatabaseIfMissing();

$pdo = Database::connect();
echo "Connected to MySQL OK\n";

// ── users ──────────────────────────────────────────────────────────────────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS users (
        id            INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        username      VARCHAR(50)     NOT NULL,
        email         VARCHAR(255)    NOT NULL,
        password_hash VARCHAR(255)    NOT NULL,
        role          ENUM('user','admin') NOT NULL DEFAULT 'user',
        created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY uq_username (username),
        UNIQUE KEY uq_email (email)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "Table 'users' OK\n";

// ── login_attempts ─────────────────────────────────────────────────────────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS login_attempts (
        id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
        username     VARCHAR(50)  NOT NULL,
        attempted_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        success      TINYINT(1)   NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY idx_username_time (username, attempted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "Table 'login_attempts' OK\n";

// ── ledger_entries ─────────────────────────────────────────────────────────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS ledger_entries (
        position     INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        entry_id     VARCHAR(255)    NOT NULL,
        amount       VARCHAR(64)     NOT NULL,
        description  VARCHAR(500)    NOT NULL,
        date         VARCHAR(20)     NOT NULL,
        category     VARCHAR(100)    NOT NULL,
        entry_hash   CHAR(64)        NOT NULL,
        prev_hash    CHAR(64)        NOT NULL,
        created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        user_id      INT UNSIGNED    NOT NULL DEFAULT 0,
        PRIMARY KEY (position),
        UNIQUE KEY uq_entry_id (entry_id),
        KEY idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "Table 'ledger_entries' OK\n";

// ── audit_log ──────────────────────────────────────────────────────────────
$pdo->exec("
    CREATE TABLE IF NOT EXISTS audit_log (
        id           INT UNSIGNED NOT NULL AUTO_INCREMENT,
        verified_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        status       ENUM('intact','tampered') NOT NULL,
        entry_count  INT UNSIGNED NOT NULL,
        tampered_ids TEXT         NOT NULL,
        user_id      INT UNSIGNED NOT NULL DEFAULT 0,
        PRIMARY KEY (id),
        KEY idx_user_id (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");
echo "Table 'audit_log' OK\n";

echo "\nMigration complete. All tables ready.\n";
