<?php
declare(strict_types=1);
require __DIR__ . '/../vendor/autoload.php';

use ExpenseLedger\Database;
use ExpenseLedger\MysqlLedgerStore;
use ExpenseLedger\AuthStore;
use ExpenseLedger\LedgerFactory;
use ExpenseLedger\ExpenseEntry;

echo "=== MySQL Connection Test ===\n\n";

// 1. Create database if missing
echo "1. Creating database if missing...\n";
Database::createDatabaseIfMissing();
echo "   OK\n\n";

// 2. Run migration
echo "2. Running migration...\n";
require __DIR__ . '/migrate.php';
echo "\n";

// 3. Test ledger store
echo "3. Testing MysqlLedgerStore...\n";
$store  = new MysqlLedgerStore(userId: 1, isAdmin: false);
$ledger = LedgerFactory::create('test-hmac-key');

$entry = new ExpenseEntry('mysql-test-1', '49.99', 'MySQL test entry', date('Y-m-d'), 'Office');
$he    = $ledger->append($entry);
$store->append($he);
echo "   Inserted entry OK\n";

$rows = $store->loadAll();
echo "   Loaded " . count($rows) . " row(s)\n";
echo "   entry_id=" . $rows[array_key_last($rows)]->entry->id . "\n";

$store->clear();
echo "   Cleared OK\n\n";

// 4. Test AuthStore
echo "4. Testing AuthStore...\n";
$auth = new AuthStore();

$username = 'testuser_' . uniqid();
$id = $auth->register($username, $username . '@example.com', 'password123');
echo "   Registered user id={$id}\n";

$user = $auth->attempt($username, 'password123');
echo "   Login " . ($user ? "OK (role={$user['role']})" : "FAILED") . "\n";

$wrong = $auth->attempt($username, 'wrongpassword');
echo "   Wrong password correctly rejected: " . ($wrong === null ? 'YES' : 'NO') . "\n\n";

echo "=== All MySQL tests passed ===\n";
