<?php
declare(strict_types=1);
require_once __DIR__ . '/../vendor/autoload.php';

use ExpenseLedger\Auth;
use ExpenseLedger\AuthStore;
use ExpenseLedger\Database;
use ExpenseLedger\LedgerFactory;
use ExpenseLedger\MysqlLedgerStore;
use ExpenseLedger\ExpenseEntry;
use ExpenseLedger\Exception\ValidationException;

// ── Auth guard ────────────────────────────────────────────────────────────────
Auth::check(); // Redirects to login.php if not signed in
$currentUserId = Auth::userId();
$isAdmin       = Auth::isAdmin();

// ── HMAC key (file-based, outside web root) ───────────────────────────────────
$dataDir = __DIR__ . '/../data';
$keyFile = $dataDir . '/hmac.key';

if (!is_dir($dataDir)) {
    mkdir($dataDir, 0750, true);
}
if (!is_file($keyFile)) {
    file_put_contents($keyFile, bin2hex(random_bytes(32)), LOCK_EX);
    chmod($keyFile, 0600);
}
$hmacKey = trim(file_get_contents($keyFile));

// ── Bootstrap components ──────────────────────────────────────────────────────
$store    = new MysqlLedgerStore($currentUserId, $isAdmin);
$ledger   = LedgerFactory::create($hmacKey);
$verifier = LedgerFactory::createVerifier($hmacKey);

foreach ($store->loadAll() as $he) {
    $ledger->restore($he);
}

// ── Handle POST actions ───────────────────────────────────────────────────────
$errors  = [];
$success = null;
$report  = null;
$action  = $_POST['action'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Auth::verifyCsrf();

    if ($action === 'add') {
        try {
            $entry = new ExpenseEntry(
                id:          trim($_POST['id'] ?? ''),
                amount:      trim($_POST['amount'] ?? ''),
                description: trim($_POST['description'] ?? ''),
                date:        trim($_POST['date'] ?? ''),
                category:    trim($_POST['category'] ?? ''),
            );
            $he = $ledger->append($entry);
            $store->append($he);
            $success = 'Entry <strong>' . htmlspecialchars($entry->id) . '</strong> added.';
        } catch (ValidationException $e) {
            $errors[] = $e->getMessage();
        }

    } elseif ($action === 'verify') {
        $report = $verifier->verifyLedger($ledger);
        $store->logVerification($report);

    } elseif ($action === 'tamper') {
        $tid  = trim($_POST['tamper_id'] ?? '');
        $tamt = trim($_POST['tamper_amount'] ?? '');
        if ($tid !== '' && $tamt !== '') {
            if ($store->tamperAmount($tid, $tamt)) {
                $success = '⚠️ Entry <strong>' . htmlspecialchars($tid) . '</strong> tampered. Run Verify to detect it.';
                $ledger = LedgerFactory::create($hmacKey);
                foreach ($store->loadAll() as $he) {
                    $ledger->restore($he);
                }
            } else {
                $errors[] = 'Entry ID not found: ' . htmlspecialchars($tid);
            }
        } else {
            $errors[] = 'Provide both an entry ID and a new amount to tamper.';
        }

    } elseif ($action === 'clear') {
        $store->clear();
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;

    } elseif ($action === 'export_csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="ledger_' . date('Ymd_His') . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, ['#', 'ID', 'Date', 'Description', 'Category', 'Amount', 'Entry Hash', 'Prev Hash']);
        foreach ($ledger->entries() as $i => $he) {
            fputcsv($out, [
                $i, $he->entry->id, $he->entry->date, $he->entry->description,
                $he->entry->category, $he->entry->amount, $he->entry_hash, $he->prev_hash,
            ]);
        }
        fclose($out);
        exit;
    }
}

// ── View data ─────────────────────────────────────────────────────────────────
$entries  = $ledger->entries();
$auditLog = $store->recentAuditLog(5);

$filterCat  = trim($_GET['cat'] ?? '');
$filterDate = trim($_GET['date'] ?? '');
$filtered   = array_values(array_filter($entries, function ($he) use ($filterCat, $filterDate) {
    if ($filterCat  !== '' && $he->entry->category !== $filterCat)  return false;
    if ($filterDate !== '' && $he->entry->date     !== $filterDate) return false;
    return true;
}));

$allCats = array_unique(array_map(fn($he) => $he->entry->category, $entries));
sort($allCats);

$total  = array_reduce($entries, fn($c, $he) => $c + (float)$he->entry->amount, 0.0);
$catMap = [];
foreach ($entries as $he) {
    $catMap[$he->entry->category] = ($catMap[$he->entry->category] ?? 0) + (float)$he->entry->amount;
}
arsort($catMap);
$topCat = array_key_first($catMap) ?? '—';

$tamperedIds = [];
if ($report) {
    foreach ($report->tampered_entries as $t) {
        $tamperedIds[$t->id] = true;
    }
}

// Admin: load user list
$authStore = new AuthStore();
$allUsers  = $isAdmin ? $authStore->allUsers() : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Expense Ledger Integrity Checker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body { background: #f0f2f5; }
        .hash-mono { font-family: monospace; font-size: .7rem; color: #6c757d; word-break: break-all; }
        .tampered-row { background: #fff0f0 !important; }
        .intact-row   { background: #f0fff4 !important; }
        .grad { background: linear-gradient(135deg, #0d6efd, #0dcaf0); }
        .card-header.grad { color: #fff; }
        .audit-dot-ok  { color: #198754; }
        .audit-dot-bad { color: #dc3545; }
    </style>
</head>
<body>

<!-- ── Navbar ── -->
<nav class="navbar navbar-dark grad mb-4 shadow-sm">
    <div class="container-fluid px-4">
        <span class="navbar-brand fw-bold fs-5">
            <i class="bi bi-shield-lock-fill me-2"></i>Expense Ledger
        </span>
        <div class="d-flex align-items-center gap-3">
            <span class="text-white-50 small d-none d-md-inline">
                Signed in as
                <strong class="text-white"><?= htmlspecialchars(Auth::username()) ?></strong>
                <?php if ($isAdmin): ?>
                <span class="badge bg-warning text-dark ms-1">Admin</span>
                <?php endif; ?>
            </span>
            <a href="logout.php" class="btn btn-sm btn-outline-light">
                <i class="bi bi-box-arrow-right me-1"></i>Logout
            </a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4 pb-5">

    <!-- Alerts -->
    <?php if ($errors): ?>
    <div class="alert alert-danger alert-dismissible fade show shadow-sm">
        <i class="bi bi-exclamation-triangle-fill me-2"></i>
        <?= implode('<br>', array_map('htmlspecialchars', $errors)) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show shadow-sm">
        <i class="bi bi-check-circle-fill me-2"></i><?= $success ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <?php if ($report): ?>
    <div class="alert <?= $report->status === 'intact' ? 'alert-success' : 'alert-danger' ?> alert-dismissible fade show shadow-sm">
        <?php if ($report->status === 'intact'): ?>
            <i class="bi bi-shield-check me-2"></i>
            <strong>Ledger is intact.</strong> All <?= $report->verified_count ?> entries verified.
        <?php else: ?>
            <i class="bi bi-shield-x me-2"></i>
            <strong>Tampering detected!</strong> <?= count($report->tampered_entries) ?> of <?= $report->verified_count ?> entries failed.
            <ul class="mb-0 mt-1 small">
            <?php foreach ($report->tampered_entries as $t): ?>
                <li>Entry <code><?= htmlspecialchars($t->id) ?></code> at position <?= $t->position ?>
                    — expected <code><?= substr($t->expected_hash, 0, 12) ?>…</code>
                    got <code><?= substr($t->actual_hash, 0, 12) ?>…</code>
                </li>
            <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <div class="row g-4">

        <!-- ── Left sidebar ── -->
        <div class="col-xl-3 col-lg-4">

            <!-- Add Entry -->
            <div class="card shadow-sm mb-4">
                <div class="card-header grad fw-semibold">
                    <i class="bi bi-plus-circle me-2"></i>Add Expense Entry
                </div>
                <div class="card-body">
                    <form method="post">
                        <input type="hidden" name="action" value="add">
                        <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">

                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">Entry ID</label>
                            <input type="text" name="id" class="form-control form-control-sm"
                                   placeholder="exp-001"
                                   value="<?= htmlspecialchars($_POST['id'] ?? '') ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">Amount ($)</label>
                            <input type="text" name="amount" class="form-control form-control-sm"
                                   placeholder="49.99"
                                   value="<?= htmlspecialchars($_POST['amount'] ?? '') ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">Description</label>
                            <input type="text" name="description" class="form-control form-control-sm"
                                   placeholder="Office supplies"
                                   value="<?= htmlspecialchars($_POST['description'] ?? '') ?>">
                        </div>
                        <div class="mb-2">
                            <label class="form-label small fw-semibold mb-1">Date</label>
                            <input type="date" name="date" class="form-control form-control-sm"
                                   value="<?= htmlspecialchars($_POST['date'] ?? date('Y-m-d')) ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold mb-1">Category</label>
                            <select name="category" class="form-select form-select-sm">
                                <?php
                                $cats = ['Travel', 'Food', 'Office', 'Software', 'Hardware', 'Marketing', 'Other'];
                                $sel  = $_POST['category'] ?? 'Other';
                                foreach ($cats as $c):
                                ?>
                                <option value="<?= $c ?>" <?= $c === $sel ? 'selected' : '' ?>><?= $c ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary btn-sm w-100">
                            <i class="bi bi-plus-lg me-1"></i>Add to Ledger
                        </button>
                    </form>
                </div>
            </div>

            <!-- Tamper Simulation -->
            <div class="card shadow-sm border-warning mb-4">
                <div class="card-header bg-warning text-dark fw-semibold">
                    <i class="bi bi-bug me-2"></i>Tamper Simulation
                </div>
                <div class="card-body">
                    <p class="small text-muted mb-2">Mutate an entry's amount without recomputing its hash, then Verify to detect it.</p>
                    <form method="post">
                        <input type="hidden" name="action" value="tamper">
                        <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">
                        <div class="mb-2">
                            <input type="text" name="tamper_id" class="form-control form-control-sm"
                                   placeholder="Entry ID to tamper">
                        </div>
                        <div class="mb-2">
                            <input type="text" name="tamper_amount" class="form-control form-control-sm"
                                   placeholder="New (fake) amount">
                        </div>
                        <button type="submit" class="btn btn-warning btn-sm w-100"
                                onclick="return confirm('This corrupts the ledger for demo purposes. Continue?')"
                                <?= empty($entries) ? 'disabled' : '' ?>>
                            <i class="bi bi-lightning-charge me-1"></i>Tamper Entry
                        </button>
                    </form>
                </div>
            </div>

            <!-- Audit Log -->
            <div class="card shadow-sm mb-4">
                <div class="card-header grad fw-semibold">
                    <i class="bi bi-journal-text me-2"></i>Audit Log
                </div>
                <div class="card-body p-0">
                    <?php if (empty($auditLog)): ?>
                    <p class="text-muted small p-3 mb-0">No verifications run yet.</p>
                    <?php else: ?>
                    <ul class="list-group list-group-flush small">
                        <?php foreach ($auditLog as $log): ?>
                        <li class="list-group-item py-2">
                            <span class="<?= $log['status'] === 'intact' ? 'audit-dot-ok' : 'audit-dot-bad' ?>">
                                <i class="bi bi-circle-fill me-1" style="font-size:.5rem;vertical-align:middle;"></i>
                            </span>
                            <strong><?= ucfirst($log['status']) ?></strong> — <?= $log['entry_count'] ?> entries
                            <div class="text-muted" style="font-size:.7rem;"><?= $log['verified_at'] ?></div>
                            <?php if ($log['tampered_ids']): ?>
                            <div class="text-danger" style="font-size:.7rem;">Tampered: <?= htmlspecialchars($log['tampered_ids']) ?></div>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Admin: User list -->
            <?php if ($isAdmin && !empty($allUsers)): ?>
            <div class="card shadow-sm border-warning">
                <div class="card-header bg-warning text-dark fw-semibold">
                    <i class="bi bi-people me-2"></i>Registered Users
                </div>
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush small">
                        <?php foreach ($allUsers as $u): ?>
                        <li class="list-group-item py-2 d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= htmlspecialchars($u['username']) ?></strong>
                                <div class="text-muted" style="font-size:.7rem;"><?= htmlspecialchars($u['email']) ?></div>
                            </div>
                            <span class="badge <?= $u['role'] === 'admin' ? 'bg-warning text-dark' : 'bg-secondary' ?>">
                                <?= $u['role'] ?>
                            </span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

        </div>

        <!-- ── Main content ── -->
        <div class="col-xl-9 col-lg-8">

            <!-- Stats cards -->
            <?php if (!empty($entries)): ?>
            <div class="row g-3 mb-4">
                <div class="col-sm-3">
                    <div class="card text-white bg-primary shadow-sm border-0 text-center">
                        <div class="card-body py-3">
                            <div class="fs-3 fw-bold"><?= count($entries) ?></div>
                            <div class="small">Entries</div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card text-white bg-success shadow-sm border-0 text-center">
                        <div class="card-body py-3">
                            <div class="fs-3 fw-bold">$<?= number_format($total, 2) ?></div>
                            <div class="small">Total Spend</div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card text-white bg-info shadow-sm border-0 text-center">
                        <div class="card-body py-3">
                            <div class="fs-3 fw-bold"><?= htmlspecialchars($topCat) ?></div>
                            <div class="small">Top Category</div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-3">
                    <div class="card text-white bg-secondary shadow-sm border-0 text-center">
                        <div class="card-body py-3">
                            <div class="fs-3 fw-bold"><?= count($catMap) ?></div>
                            <div class="small">Categories</div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Ledger table -->
            <div class="card shadow-sm">
                <div class="card-header grad d-flex flex-wrap gap-2 align-items-center justify-content-between">
                    <span class="fw-semibold">
                        <i class="bi bi-link-45deg me-1"></i>Ledger Chain
                        <span class="badge bg-white text-primary ms-1"><?= count($entries) ?></span>
                        <?php if ($isAdmin): ?>
                        <span class="badge bg-warning text-dark ms-1">All users</span>
                        <?php endif; ?>
                    </span>
                    <div class="d-flex gap-2 flex-wrap">
                        <!-- Filter -->
                        <form method="get" class="d-flex gap-1">
                            <select name="cat" class="form-select form-select-sm" style="width:130px">
                                <option value="">All categories</option>
                                <?php foreach ($allCats as $c): ?>
                                <option value="<?= htmlspecialchars($c) ?>" <?= $filterCat === $c ? 'selected' : '' ?>><?= htmlspecialchars($c) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="date" name="date" class="form-control form-control-sm" style="width:140px"
                                   value="<?= htmlspecialchars($filterDate) ?>">
                            <button type="submit" class="btn btn-sm btn-light"><i class="bi bi-funnel"></i></button>
                            <?php if ($filterCat || $filterDate): ?>
                            <a href="?" class="btn btn-sm btn-outline-light"><i class="bi bi-x"></i></a>
                            <?php endif; ?>
                        </form>
                        <!-- Actions -->
                        <form method="post" class="d-inline">
                            <input type="hidden" name="action" value="verify">
                            <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">
                            <button class="btn btn-sm btn-light" <?= empty($entries) ? 'disabled' : '' ?>>
                                <i class="bi bi-shield-check me-1"></i>Verify
                            </button>
                        </form>
                        <form method="post" class="d-inline">
                            <input type="hidden" name="action" value="export_csv">
                            <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">
                            <button class="btn btn-sm btn-outline-light" <?= empty($entries) ? 'disabled' : '' ?>>
                                <i class="bi bi-download me-1"></i>CSV
                            </button>
                        </form>
                        <form method="post" class="d-inline"
                              onsubmit="return confirm('Delete your entries and audit log?')">
                            <input type="hidden" name="action" value="clear">
                            <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">
                            <button class="btn btn-sm btn-outline-light" <?= empty($entries) ? 'disabled' : '' ?>>
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>

                <?php if (empty($filtered)): ?>
                <div class="card-body text-center text-muted py-5">
                    <i class="bi bi-inbox display-4 d-block mb-3"></i>
                    <?= empty($entries) ? 'No entries yet. Add your first expense.' : 'No entries match the current filter.' ?>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm table-hover table-bordered mb-0 align-middle">
                        <thead class="table-light small">
                            <tr>
                                <th>#</th>
                                <th>ID</th>
                                <?php if ($isAdmin): ?><th>User</th><?php endif; ?>
                                <th>Date</th>
                                <th>Description</th>
                                <th>Category</th>
                                <th class="text-end">Amount</th>
                                <th>Entry Hash</th>
                                <th>Prev Hash</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($filtered as $i => $he):
                            $isTampered = isset($tamperedIds[$he->entry->id]);
                            $rowClass   = $isTampered ? 'tampered-row' : ($report ? 'intact-row' : '');
                        ?>
                            <tr class="<?= $rowClass ?>">
                                <td class="text-muted small"><?= $i ?></td>
                                <td>
                                    <code class="small"><?= htmlspecialchars($he->entry->id) ?></code>
                                    <?php if ($isTampered): ?>
                                    <span class="badge bg-danger ms-1"><i class="bi bi-exclamation-triangle-fill"></i> Tampered</span>
                                    <?php elseif ($report): ?>
                                    <span class="badge bg-success ms-1"><i class="bi bi-check-lg"></i></span>
                                    <?php endif; ?>
                                </td>
                                <?php if ($isAdmin): ?>
                                <td class="small text-muted">uid:<?= $i ?></td>
                                <?php endif; ?>
                                <td class="small"><?= htmlspecialchars($he->entry->date) ?></td>
                                <td class="small"><?= htmlspecialchars($he->entry->description) ?></td>
                                <td><span class="badge bg-secondary"><?= htmlspecialchars($he->entry->category) ?></span></td>
                                <td class="text-end fw-semibold small">$<?= htmlspecialchars($he->entry->amount) ?></td>
                                <td><span class="hash-mono" title="<?= htmlspecialchars($he->entry_hash) ?>"><?= substr($he->entry_hash, 0, 14) ?>…</span></td>
                                <td><span class="hash-mono" title="<?= htmlspecialchars($he->prev_hash) ?>"><?= substr($he->prev_hash, 0, 14) ?>…</span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-footer bg-light py-2">
                    <a class="text-decoration-none small text-muted" data-bs-toggle="collapse" href="#hashDetail">
                        <i class="bi bi-chevron-down me-1"></i>Show full hashes
                    </a>
                    <div class="collapse mt-2" id="hashDetail">
                        <?php foreach ($filtered as $i => $he): ?>
                        <div class="mb-2 p-2 bg-white border rounded small font-monospace">
                            <span class="fw-bold text-primary">[<?= $i ?>] <?= htmlspecialchars($he->entry->id) ?></span><br>
                            <span class="text-muted">entry_hash:</span> <?= htmlspecialchars($he->entry_hash) ?><br>
                            <span class="text-muted">prev_hash: </span> <?= htmlspecialchars($he->prev_hash) ?>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Category breakdown -->
            <?php if (!empty($catMap)): ?>
            <div class="card shadow-sm mt-4">
                <div class="card-header grad fw-semibold">
                    <i class="bi bi-bar-chart me-2"></i>Spend by Category
                </div>
                <div class="card-body">
                    <?php foreach ($catMap as $cat => $amt): ?>
                    <div class="d-flex justify-content-between small mb-1">
                        <span><?= htmlspecialchars($cat) ?></span>
                        <span class="fw-semibold">$<?= number_format($amt, 2) ?></span>
                    </div>
                    <div class="progress mb-2" style="height:6px">
                        <div class="progress-bar bg-primary"
                             style="width:<?= $total > 0 ? round($amt / $total * 100) : 0 ?>%"></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
