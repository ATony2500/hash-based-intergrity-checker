<?php
declare(strict_types=1);
require_once __DIR__ . '/../vendor/autoload.php';

use ExpenseLedger\Auth;
use ExpenseLedger\AuthStore;
use ExpenseLedger\Database;

Auth::start();
if (!empty($_SESSION['logged_in'])) {
    header('Location: index.php');
    exit;
}

$auth  = new AuthStore();
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Auth::verifyCsrf();
    try {
        $user = $auth->attempt(
            $_POST['username'] ?? '',
            $_POST['password'] ?? ''
        );
        if ($user) {
            Auth::login($user);
            header('Location: index.php');
            exit;
        }
        $error = 'Invalid username or password.';
    } catch (\RuntimeException $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login — Expense Ledger</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<style>
body { background: #f0f2f5; }
.brand-grad { background: linear-gradient(135deg, #0d6efd, #0dcaf0); }
</style>
</head>
<body>
<div class="min-vh-100 d-flex align-items-center justify-content-center">
  <div class="card shadow-lg" style="width:100%;max-width:400px">

    <div class="card-header brand-grad text-white text-center py-4">
      <i class="bi bi-shield-lock-fill fs-2 d-block mb-1"></i>
      <h4 class="mb-0 fw-bold">Sign In</h4>
      <div class="small opacity-75">Expense Ledger Integrity Checker</div>
    </div>

    <div class="card-body p-4">

      <?php if ($error): ?>
      <div class="alert alert-danger py-2">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
      </div>
      <?php endif; ?>

      <?php if (!empty($_GET['registered'])): ?>
      <div class="alert alert-success py-2">
        <i class="bi bi-check-circle-fill me-2"></i>Account created. Please sign in.
      </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">

        <div class="mb-3">
          <label class="form-label fw-semibold">Username</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-person"></i></span>
            <input type="text" name="username" class="form-control"
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                   required autofocus autocomplete="username">
          </div>
        </div>

        <div class="mb-4">
          <label class="form-label fw-semibold">Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock"></i></span>
            <input type="password" name="password" id="pwField" class="form-control"
                   required autocomplete="current-password">
            <button type="button" class="btn btn-outline-secondary" id="togglePw" tabindex="-1">
              <i class="bi bi-eye"></i>
            </button>
          </div>
        </div>

        <button type="submit" class="btn btn-primary w-100 fw-semibold">
          <i class="bi bi-box-arrow-in-right me-1"></i>Sign In
        </button>
      </form>
    </div>

    <div class="card-footer text-center text-muted small py-3">
      No account yet? <a href="register.php" class="fw-semibold">Register here</a>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('togglePw')?.addEventListener('click', function () {
    const pw = document.getElementById('pwField');
    const icon = this.querySelector('i');
    if (pw.type === 'password') {
        pw.type = 'text';
        icon.className = 'bi bi-eye-slash';
    } else {
        pw.type = 'password';
        icon.className = 'bi bi-eye';
    }
});
</script>
</body>
</html>
