<?php
declare(strict_types=1);
require_once __DIR__ . '/../vendor/autoload.php';

use ExpenseLedger\Auth;
use ExpenseLedger\AuthStore;
use ExpenseLedger\Database;

Auth::start();
if (!empty($_SESSION['logged_in'])) {
    header('Location: index.php');
    exit;
}

$auth    = new AuthStore();
$error   = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Auth::verifyCsrf();
    try {
        $auth->register(
            $_POST['username'] ?? '',
            $_POST['email']    ?? '',
            $_POST['password'] ?? ''
        );
        $success = true;
    } catch (\RuntimeException $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Register — Expense Ledger</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<style>
body { background: #f0f2f5; }
.brand-grad { background: linear-gradient(135deg, #0d6efd, #0dcaf0); }
</style>
</head>
<body>
<div class="min-vh-100 d-flex align-items-center justify-content-center py-4">
  <div class="card shadow-lg" style="width:100%;max-width:430px">

    <div class="card-header brand-grad text-white text-center py-4">
      <i class="bi bi-shield-lock-fill fs-2 d-block mb-1"></i>
      <h4 class="mb-0 fw-bold">Create Account</h4>
      <div class="small opacity-75">Expense Ledger Integrity Checker</div>
    </div>

    <div class="card-body p-4">

      <?php if ($success): ?>
      <div class="alert alert-success">
        <i class="bi bi-check-circle-fill me-2"></i>
        Account created! <a href="login.php" class="alert-link fw-semibold">Sign in now</a>
      </div>
      <?php else: ?>

      <?php if ($error): ?>
      <div class="alert alert-danger py-2">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
      </div>
      <?php endif; ?>

      <form method="post" novalidate>
        <input type="hidden" name="csrf_token" value="<?= Auth::csrf() ?>">

        <div class="mb-3">
          <label class="form-label fw-semibold">Username</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-person"></i></span>
            <input type="text" name="username" class="form-control"
                   placeholder="3–50 characters"
                   value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                   required autocomplete="username">
          </div>
        </div>

        <div class="mb-3">
          <label class="form-label fw-semibold">Email</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-envelope"></i></span>
            <input type="email" name="email" class="form-control"
                   placeholder="you@example.com"
                   value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                   required autocomplete="email">
          </div>
        </div>

        <div class="mb-4">
          <label class="form-label fw-semibold">Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="bi bi-lock"></i></span>
            <input type="password" name="password" id="pwField" class="form-control"
                   placeholder="At least 8 characters" required autocomplete="new-password">
            <button type="button" class="btn btn-outline-secondary" id="togglePw" tabindex="-1">
              <i class="bi bi-eye"></i>
            </button>
          </div>
          <div class="form-text">Minimum 8 characters. Use a mix of letters, numbers and symbols.</div>
        </div>

        <button type="submit" class="btn btn-primary w-100 fw-semibold">
          <i class="bi bi-person-plus me-1"></i>Register
        </button>
      </form>

      <?php endif; ?>
    </div>

    <div class="card-footer text-center text-muted small py-3">
      Already have an account? <a href="login.php" class="fw-semibold">Sign in</a>
    </div>

  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('togglePw')?.addEventListener('click', function () {
    const pw = document.getElementById('pwField');
    const icon = this.querySelector('i');
    if (pw.type === 'password') {
        pw.type = 'text';
        icon.className = 'bi bi-eye-slash';
    } else {
        pw.type = 'password';
        icon.className = 'bi bi-eye';
    }
});
</script>
</body>
</html>
