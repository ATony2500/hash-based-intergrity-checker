/**
 * Expense Ledger — JavaScript JSON codec
 *
 * Matches the PHP Serializer::encodeLedger / decodeLedger JSON schema.
 * Amount is always stored as a decimal string to avoid floating-point issues.
 */

const REQUIRED_FIELDS = ['id', 'amount', 'description', 'date', 'category', 'entry_hash', 'prev_hash'];

/**
 * Encode an array of hashed entry objects to a JSON string.
 *
 * @param {Array<{id: string, amount: string, description: string, date: string, category: string, entry_hash: string, prev_hash: string}>} entries
 * @returns {string} JSON string
 */
function encodeLedger(entries) {
    if (!Array.isArray(entries)) {
        throw new TypeError('entries must be an array');
    }
    return JSON.stringify({ entries });
}

/**
 * Decode a JSON string into an array of hashed entry objects.
 *
 * @param {string} json
 * @returns {{ entries: Array }} Decoded ledger object
 * @throws {Error} On malformed JSON or missing required fields
 */
function decodeLedger(json) {
    let data;
    try {
        data = JSON.parse(json);
    } catch (e) {
        throw new Error('Malformed JSON: ' + e.message);
    }

    if (!data || !Object.prototype.hasOwnProperty.call(data, 'entries')) {
        throw new Error("Missing required top-level key 'entries'.");
    }

    if (!Array.isArray(data.entries)) {
        throw new Error("Key 'entries' must be an array.");
    }

    data.entries.forEach((row, i) => {
        for (const field of REQUIRED_FIELDS) {
            if (!Object.prototype.hasOwnProperty.call(row, field)) {
                throw new Error(`Entry at index ${i} is missing required field '${field}'.`);
            }
            if (typeof row[field] !== 'string') {
                throw new Error(`Entry at index ${i}: field '${field}' must be a string.`);
            }
        }
    });

    return data;
}

module.exports = { encodeLedger, decodeLedger };
