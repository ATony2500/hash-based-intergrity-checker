const fc = require('fast-check');
const { encodeLedger, decodeLedger } = require('./ledger');

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function makeEntry(overrides = {}) {
    return {
        id: 'entry-1',
        amount: '42.00',
        description: 'Office supplies',
        date: '2024-01-15',
        category: 'supplies',
        entry_hash: 'abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234abcd1234',
        prev_hash: '0000000000000000000000000000000000000000000000000000000000000000',
        ...overrides,
    };
}

// ---------------------------------------------------------------------------
// Unit tests — encode
// ---------------------------------------------------------------------------

describe('encodeLedger', () => {
    test('encodes an empty array', () => {
        const result = encodeLedger([]);
        expect(result).toBe('{"entries":[]}');
    });

    test('encodes a single entry', () => {
        const entry = makeEntry();
        const json = encodeLedger([entry]);
        const parsed = JSON.parse(json);
        expect(parsed.entries).toHaveLength(1);
        expect(parsed.entries[0]).toEqual(entry);
    });

    test('encodes multiple entries preserving order', () => {
        const e1 = makeEntry({ id: 'e1' });
        const e2 = makeEntry({ id: 'e2', prev_hash: e1.entry_hash });
        const json = encodeLedger([e1, e2]);
        const parsed = JSON.parse(json);
        expect(parsed.entries[0].id).toBe('e1');
        expect(parsed.entries[1].id).toBe('e2');
    });

    test('throws TypeError when entries is not an array', () => {
        expect(() => encodeLedger(null)).toThrow(TypeError);
        expect(() => encodeLedger('bad')).toThrow(TypeError);
        expect(() => encodeLedger({})).toThrow(TypeError);
    });
});

// ---------------------------------------------------------------------------
// Unit tests — decode
// ---------------------------------------------------------------------------

describe('decodeLedger', () => {
    test('decodes a single entry round-trip', () => {
        const entry = makeEntry();
        const decoded = decodeLedger(encodeLedger([entry]));
        expect(decoded.entries).toHaveLength(1);
        expect(decoded.entries[0]).toEqual(entry);
    });

    test('decodes multiple entries round-trip', () => {
        const entries = [makeEntry({ id: 'a' }), makeEntry({ id: 'b' })];
        const decoded = decodeLedger(encodeLedger(entries));
        expect(decoded.entries).toEqual(entries);
    });

    test('throws on malformed JSON', () => {
        expect(() => decodeLedger('not json {')).toThrow(/Malformed JSON/i);
    });

    test('throws when top-level entries key is missing', () => {
        expect(() => decodeLedger('{"data":[]}')).toThrow(/entries/i);
    });

    test('throws when a required field is missing from an entry', () => {
        const entry = makeEntry();
        delete entry.entry_hash;
        const json = JSON.stringify({ entries: [entry] });
        expect(() => decodeLedger(json)).toThrow(/entry_hash/i);
    });

    test('throws when a required field is not a string', () => {
        const entry = makeEntry({ amount: 42 }); // number instead of string
        const json = JSON.stringify({ entries: [entry] });
        expect(() => decodeLedger(json)).toThrow(/amount/i);
    });
});

// ---------------------------------------------------------------------------
// Property-based test — round-trip
// Feature: expense-ledger-integrity, Property 4: Ledger serialization round-trip
// ---------------------------------------------------------------------------

describe('Property 4: Ledger serialization round-trip', () => {
    // Validates: Requirements 6.3

    const entryArb = fc.record({
        id:          fc.string({ minLength: 1 }),
        amount:      fc.string({ minLength: 1 }),
        description: fc.string({ minLength: 1 }),
        date:        fc.string({ minLength: 1 }),
        category:    fc.string({ minLength: 1 }),
        entry_hash:  fc.string({ minLength: 1 }),
        prev_hash:   fc.string({ minLength: 1 }),
    });

    const ledgerArb = fc.array(entryArb, { maxLength: 5 });

    test('encode then decode produces equivalent ledger', () => {
        fc.assert(
            fc.property(ledgerArb, (entries) => {
                const decoded = decodeLedger(encodeLedger(entries));
                expect(decoded.entries).toEqual(entries);
            }),
            { numRuns: 100 }
        );
    });
});
